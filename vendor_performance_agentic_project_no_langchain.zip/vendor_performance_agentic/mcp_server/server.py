from mcp.server.fastmcp import FastMCP
mcp=FastMCP('vendor-performance-tools',host='127.0.0.1',port=8001,stateless_http=True)
@mcp.tool()
def vendor_score_summary(username:str)->dict:
 """Return vendor KPIs scoped to the user's demo persona categories."""
 from shared.security import user_context
 from backend.agents.scoring_agent import run
 u=user_context(username)
 if not u:return {'error':'unknown user'}
 r=run(u);return {'persona':u['persona'],'vendor_count':r['count'],'average_score':r['average_score'],'preferred':r['preferred'],'needs_action':r['needs_action']}
@mcp.tool()
def search_supplier_playbooks(query:str,topic:str='')->list:
 """Search synthetic supplier performance playbooks."""
 from backend.agents.retrieval_agent import retrieve
 return retrieve(query,topic,3)
if __name__=='__main__':mcp.run(transport='streamable-http')
