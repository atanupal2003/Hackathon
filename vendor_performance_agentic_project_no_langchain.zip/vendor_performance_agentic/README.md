# Vendor Performance Scoring — Modular Agentic AI

Components: Streamlit frontend; FastAPI backend; separate MCP server; scoring/recommendation/RAG agents; ChromaDB supplier playbooks; SQLite LLM usage and audit; synthetic source CSVs.

## Run (Python 3.10–3.12 recommended)
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:PYTHONPATH="."
```
Use three terminals from project root:
1. `python -m mcp_server.server` (MCP :8001)
2. `python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload` (API :8000; docs `/docs`)
3. `streamlit run frontend/app.py --server.port 8501` (UI :8501)

## Demo users
- Procurement Manager: `procurement.manager` / `ProcureDemo!26`
- Operations Manager: `operations.manager` / `OperateDemo!26`
- Business Admin: `business.admin` / `AdminDemo!26`
- Auditor: `auditor` / `AuditDemo!26`

## Scoring
Delivery timeliness 35%; quality 30%; cost control 20%; lead-time consistency 15%. Bands: Preferred >80; Monitor >60 to 80; Needs Action <=60. These are MVP assumptions requiring procurement calibration.

Optional LLM: set `OPENAI_API_KEY` and `OPENAI_MODEL=gpt-4o-mini` in the backend terminal. Without a key, fallback responses are provided and usage events logged. The cost rate is illustrative only.

Security: static credentials and `X-Username` are demo-only. Use verified Entra ID/OIDC/JWT, trusted claims, service-to-service authentication and secret management in production. Persona category filtering and API screen authorization are enforced in backend. ChromaDB may initialize embeddings on first use; keyword fallback is included. Never switch/suspend vendors automatically based only on model output.


## Dependency isolation and LangChain
This project does **not** use or require LangChain, Transformers, Sentence Transformers, TensorFlow, PyTorch, TorchAudio, or TorchVision directly. ChromaDB is used directly for vector retrieval, and OpenAI's SDK is used directly for optional LLM calls.

Install in a clean virtual environment to avoid conflicts from unrelated packages in an existing Python environment. NumPy is constrained to `>=1.26,<2.0` for compatibility with the supported dependency set.
