PERSONAS={
"Procurement Manager":{"username":"procurement.manager","password":"ProcureDemo!26","categories":["Packaging","Electronics","Raw Materials","Logistics","Maintenance","Office Supplies"],"screens":["Executive Dashboard","Vendor Scorecard","Vendor Explorer","Agentic Recommendations","Supplier AI Chat","LLM Usage Dashboard"]},
"Operations Manager":{"username":"operations.manager","password":"OperateDemo!26","categories":["Packaging","Raw Materials","Logistics","Maintenance"],"screens":["Executive Dashboard","Vendor Scorecard","Vendor Explorer","Agentic Recommendations","Supplier AI Chat"]},
"Business Admin":{"username":"business.admin","password":"AdminDemo!26","categories":["Packaging","Electronics","Raw Materials","Logistics","Maintenance","Office Supplies"],"screens":["Executive Dashboard","Vendor Scorecard","Vendor Explorer","Agentic Recommendations","Supplier AI Chat","LLM Usage Dashboard","Access & Audit"]},
"Auditor":{"username":"auditor","password":"AuditDemo!26","categories":["Packaging","Electronics","Raw Materials","Logistics","Maintenance","Office Supplies"],"screens":["Executive Dashboard","Vendor Scorecard","Vendor Explorer","LLM Usage Dashboard","Access & Audit"]}}
def authenticate(u,p):
 for role,r in PERSONAS.items():
  if r['username']==u and r['password']==p:return {'username':u,'persona':role,'categories':r['categories'],'screens':r['screens']}
 return None
def user_context(u):
 for role,r in PERSONAS.items():
  if r['username']==u:return {'username':u,'persona':role,'categories':r['categories'],'screens':r['screens']}
 return None
