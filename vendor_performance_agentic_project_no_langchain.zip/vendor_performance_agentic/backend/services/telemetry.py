from pathlib import Path
from datetime import datetime
import sqlite3,pandas as pd
DB=Path(__file__).resolve().parents[2]/'app_logs.db'
def conn():
 c=sqlite3.connect(DB,check_same_thread=False);c.execute('CREATE TABLE IF NOT EXISTS llm_usage(id INTEGER PRIMARY KEY,ts TEXT,username TEXT,persona TEXT,provider TEXT,model TEXT,input_tokens INTEGER,output_tokens INTEGER,latency_ms REAL,estimated_cost_usd REAL,status TEXT,purpose TEXT)');c.execute('CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY,ts TEXT,username TEXT,persona TEXT,action TEXT,details TEXT)');c.commit();return c
def audit(u,a,d=''):
 c=conn();c.execute('INSERT INTO audit_log(ts,username,persona,action,details) VALUES(?,?,?,?,?)',(datetime.now().isoformat(timespec='seconds'),u['username'],u['persona'],a,str(d)[:500]));c.commit();c.close()
def log(u,m,p,ins,outs,lat,cost,status,purpose):
 c=conn();c.execute('INSERT INTO llm_usage(ts,username,persona,provider,model,input_tokens,output_tokens,latency_ms,estimated_cost_usd,status,purpose) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(datetime.now().isoformat(timespec='seconds'),u['username'],u['persona'],p,m,int(ins),int(outs),float(lat),float(cost),status,purpose));c.commit();c.close()
def usage(u):
 c=conn();d=pd.read_sql_query('SELECT * FROM llm_usage ORDER BY ts DESC',c);c.close();return d if u['persona']=='Business Admin' else d[d.username==u['username']]
def audits(u):
 c=conn();d=pd.read_sql_query('SELECT * FROM audit_log ORDER BY ts DESC LIMIT 2000',c);c.close();return d if u['persona']=='Business Admin' else d[d.username==u['username']]
