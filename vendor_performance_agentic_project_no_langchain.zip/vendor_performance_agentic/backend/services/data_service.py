from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]; DATA=ROOT/'data'
def load(n):return pd.read_csv(DATA/n).fillna('')
def scores():
 v=load('vendors.csv');d=load('delivery_logs.csv').groupby('vendor_id').agg(total_pos=('po_id','count'),on_time_rate=('on_time','mean'),avg_delay_days=('delivery_delay_days','mean')).reset_index();q=load('quality_inspections.csv').groupby('vendor_id').agg(defect_rate=('defect_rate_pct','mean'),failed_inspections=('inspection_result',lambda x:(x=='Fail').sum())).reset_index();i=load('invoice_data.csv').groupby('vendor_id').agg(abs_invoice_variance=('invoice_variance_pct',lambda x:x.abs().mean())).reset_index();l=load('lead_time_history.csv').groupby('vendor_id').agg(lead_time_std=('actual_lead_time_days','std'),avg_lead_variance=('lead_time_variance_days','mean')).reset_index()
 df=v.merge(d,on='vendor_id').merge(q,on='vendor_id').merge(i,on='vendor_id').merge(l,on='vendor_id').fillna(0)
 df['delivery_score']=(df.on_time_rate*100).clip(0,100);df['quality_score']=(100-df.defect_rate).clip(0,100);df['cost_score']=(100-df.abs_invoice_variance*4).clip(0,100);df['consistency_score']=(100-df.lead_time_std*3).clip(0,100)
 df['vendor_score']=(.35*df.delivery_score+.30*df.quality_score+.20*df.cost_score+.15*df.consistency_score).round(2)
 df['performance_band']=df.vendor_score.apply(lambda x:'Preferred' if x>80 else ('Monitor' if x>60 else 'Needs Action'))
 df['risk_flags']=df.apply(lambda r:'; '.join([n for n,c in [('Late deliveries',r.delivery_score<80),('Quality defects',r.quality_score<95),('Invoice variance',r.cost_score<90),('Unstable lead time',r.consistency_score<75)] if c]) or 'No major rule flags',axis=1);return df
def scoped(user):return scores().query('category in @user["categories"]').copy()
def playbooks():return load('supplier_playbooks.csv').to_dict('records')
