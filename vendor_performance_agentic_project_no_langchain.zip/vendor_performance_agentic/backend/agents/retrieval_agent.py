from pathlib import Path
from backend.services.data_service import playbooks
ROOT=Path(__file__).resolve().parents[2]
def retrieve(query,topic='',k=3):
 docs=playbooks()
 try:
  import chromadb
  client=chromadb.PersistentClient(path=str(ROOT/'chroma_store'));col=client.get_or_create_collection('supplier_playbooks')
  if col.count()==0:col.add(ids=[x['playbook_id'] for x in docs],documents=[' '.join(str(x.get(z,'')) for z in ['title','topic','symptoms','checks','recommended_action']) for x in docs],metadatas=[{'topic':x['topic'],'severity':x['severity']} for x in docs])
  if col.count():
   a={'query_texts':[query],'n_results':min(k,col.count())}
   if topic:a['where']={'topic':topic}
   ids=col.query(**a)['ids'][0];return [x for x in docs if x['playbook_id'] in ids]
 except Exception:pass
 terms=[x for x in query.lower().split() if len(x)>3];rank=[]
 for x in docs:
  if topic and x['topic']!=topic:continue
  rank.append((sum(t in ' '.join(map(str,x.values())).lower() for t in terms),x))
 return [x for _,x in sorted(rank,key=lambda z:z[0],reverse=True)[:k]]
