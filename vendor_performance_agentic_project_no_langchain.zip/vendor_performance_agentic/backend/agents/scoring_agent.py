from backend.services.data_service import scoped
def run(u):
 d=scoped(u);return {'vendors':d,'count':len(d),'average_score':round(float(d.vendor_score.mean()),2) if len(d) else 0,'preferred':int((d.performance_band=='Preferred').sum()),'needs_action':int((d.performance_band=='Needs Action').sum())}
