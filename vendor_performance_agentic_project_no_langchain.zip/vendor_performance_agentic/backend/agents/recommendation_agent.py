import os,time
from backend.agents.retrieval_agent import retrieve
from backend.services.telemetry import log
def generate(prompt,u,purpose):
 t=time.time();key=os.getenv('OPENAI_API_KEY','');model=os.getenv('OPENAI_MODEL','gpt-4o-mini')
 if not key:log(u,'fallback','none',0,0,(time.time()-t)*1000,0,'fallback',purpose);return 'LLM is not configured. Review delivery reliability, defects, invoice variance and lead-time stability. Validate the source PO, inspection and invoice records before acting.'
 try:
  from openai import OpenAI
  r=OpenAI(api_key=key).chat.completions.create(model=model,temperature=.2,messages=[{'role':'system','content':'You are a careful procurement analyst. Use only supplied data, state uncertainty, never invent facts, and require human approval for sourcing decisions.'},{'role':'user','content':prompt}]);a=int(getattr(r.usage,'prompt_tokens',0) or 0);b=int(getattr(r.usage,'completion_tokens',0) or 0);cost=a*.00000015+b*.00000060
  log(u,model,'OpenAI',a,b,(time.time()-t)*1000,cost,'success',purpose);return r.choices[0].message.content or ''
 except Exception as e:log(u,model,'OpenAI',0,0,(time.time()-t)*1000,0,'error',purpose);return f'LLM request failed: {e}'
def recommend(v,u):
 topic='performance' if float(v.get('vendor_score',0))<=80 else 'sourcing';ev=retrieve(f"supplier score {v.get('vendor_score')} delivery {v.get('delivery_score')} quality {v.get('quality_score')} cost {v.get('cost_score')} lead time {v.get('consistency_score')} {v.get('risk_flags')}",topic,3)
 prompt=f'Explain score drivers, 3 practical actions, evidence to validate and human approval checkpoint. Do not change supplier status automatically. Vendor metrics: {v}; playbooks: {ev}'
 return {'answer':generate(prompt,u,'vendor_recommendation'),'evidence':ev}
def chat(q,u,summary):return generate(f'Answer only using authorized aggregates; state limitations. Question: {q}; data: {summary}',u,'supplier_chat')
