import asyncio,json,os
async def _call(name,args):
 from mcp import ClientSession
 from mcp.client.streamable_http import streamablehttp_client
 async with streamablehttp_client(os.getenv('MCP_SERVER_URL','http://127.0.0.1:8001/mcp')) as (r,w,_):
  async with ClientSession(r,w) as s:
   await s.initialize();x=await s.call_tool(name,arguments=args);o=getattr(x,'structuredContent',None)
   if o is not None:return o
   texts=[getattr(c,'text','') for c in (getattr(x,'content',[]) or [])]
   if len(texts)==1:
    try:return json.loads(texts[0])
    except Exception:return texts[0]
   return texts
def call(n,a):return asyncio.run(_call(n,a))
