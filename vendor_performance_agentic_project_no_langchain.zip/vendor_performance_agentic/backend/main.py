from fastapi import FastAPI,Header,HTTPException
from pydantic import BaseModel
from shared.security import authenticate,user_context
from backend.agents.scoring_agent import run
from backend.agents.recommendation_agent import recommend,chat
from backend.services.telemetry import audit,usage,audits
app=FastAPI(title='Vendor Performance AI API',version='1.0')
class Login(BaseModel):username:str;password:str
class VendorRequest(BaseModel):vendor_id:str
class ChatRequest(BaseModel):question:str
def current(x_username:str=Header(default='')):
 u=user_context(x_username)
 if not u:raise HTTPException(401,'Missing or invalid demo identity')
 return u
def guard(u,s):
 if s not in u['screens']:raise HTTPException(403,f"Persona {u['persona']} is not authorized for {s}")
@app.get('/health')
def health():return {'status':'ok'}
@app.post('/auth/login')
def login(b:Login):
 u=authenticate(b.username,b.password)
 if not u:raise HTTPException(401,'Invalid username/password')
 audit(u,'login','demo login');return u
@app.get('/dashboard')
def dashboard(x_username:str=Header(default='')):
 u=current(x_username);guard(u,'Executive Dashboard');r=run(u);d=r['vendors'];return {'persona':u['persona'],'vendor_count':r['count'],'average_score':r['average_score'],'preferred':r['preferred'],'needs_action':r['needs_action'],'bands':d.groupby('performance_band').size().to_dict(),'vendors':d[['vendor_id','vendor_name','category','vendor_score','performance_band']].sort_values('vendor_score').to_dict('records')}
@app.get('/vendors')
def vendors(category:str='',band:str='',min_score:float=0,x_username:str=Header(default='')):
 u=current(x_username);guard(u,'Vendor Explorer');d=run(u)['vendors']
 if category:d=d[d.category==category]
 if band:d=d[d.performance_band==band]
 return d[d.vendor_score>=min_score].sort_values('vendor_score').to_dict('records')
@app.get('/scorecards')
def scorecards(x_username:str=Header(default='')):
 u=current(x_username);guard(u,'Vendor Scorecard');return run(u)['vendors'].sort_values('vendor_score',ascending=False).to_dict('records')
@app.post('/recommend')
def recommendation(b:VendorRequest,x_username:str=Header(default='')):
 u=current(x_username);guard(u,'Agentic Recommendations');d=run(u)['vendors'];m=d[d.vendor_id==b.vendor_id]
 if m.empty:raise HTTPException(404,'Vendor not found in authorized scope')
 v=m.iloc[0].to_dict();out=recommend(v,u);audit(u,'vendor_recommendation',f"{b.vendor_id} score={v.get('vendor_score')}");return {'vendor':v,**out}
@app.post('/chat')
def chat_api(b:ChatRequest,x_username:str=Header(default='')):
 u=current(x_username);guard(u,'Supplier AI Chat')
 if not b.question.strip():raise HTTPException(400,'Question cannot be empty')
 d=run(u)['vendors'];summary=d.groupby(['category','performance_band']).agg(vendors=('vendor_id','count'),average_score=('vendor_score','mean')).reset_index().to_dict('records');ans=chat(b.question,u,summary);audit(u,'supplier_chat',b.question[:200]);return {'answer':ans}
@app.get('/llm-usage')
def llm_usage(x_username:str=Header(default='')):
 u=current(x_username);guard(u,'LLM Usage Dashboard');d=usage(u);return {'records':d.fillna('').to_dict('records'),'count':len(d),'input_tokens':int(d.input_tokens.sum()) if len(d) else 0,'output_tokens':int(d.output_tokens.sum()) if len(d) else 0,'estimated_cost_usd':float(d.estimated_cost_usd.sum()) if len(d) else 0}
@app.get('/audit')
def audit_api(x_username:str=Header(default='')):
 u=current(x_username);guard(u,'Access & Audit');return audits(u).fillna('').to_dict('records')
@app.get('/mcp-summary')
def mcp_summary(x_username:str=Header(default='')):
 u=current(x_username)
 try:
  from backend.mcp_client import call
  return call('vendor_score_summary',{'username':u['username']})
 except Exception as e:raise HTTPException(503,f'MCP server unavailable: {e}')
