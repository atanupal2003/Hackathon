import os,requests,pandas as pd,streamlit as st
API=os.getenv('VENDOR_API_URL','http://127.0.0.1:8000')
SCREENS={'Procurement Manager':['Executive Dashboard','Vendor Scorecard','Vendor Explorer','Agentic Recommendations','Supplier AI Chat','LLM Usage Dashboard'],'Operations Manager':['Executive Dashboard','Vendor Scorecard','Vendor Explorer','Agentic Recommendations','Supplier AI Chat'],'Business Admin':['Executive Dashboard','Vendor Scorecard','Vendor Explorer','Agentic Recommendations','Supplier AI Chat','LLM Usage Dashboard','Access & Audit'],'Auditor':['Executive Dashboard','Vendor Scorecard','Vendor Explorer','LLM Usage Dashboard','Access & Audit']}
st.set_page_config(page_title='Vendor Performance AI',page_icon='📊',layout='wide')
def api(method,path,user=None,**kw):
 h=kw.pop('headers',{});
 if user:h['X-Username']=user
 try:
  r=requests.request(method,API+path,headers=h,timeout=60,**kw)
  if not r.ok:st.error(f"Backend {r.status_code}: {r.text}");return None
  return r.json()
 except requests.RequestException as e:st.error(f'Backend unavailable at {API}. Start backend first. {e}');return None
if 'user' not in st.session_state:st.session_state.user=None
st.sidebar.title('📊 Vendor Performance AI')
if not st.session_state.user:
 st.title('Vendor Performance Scoring & Agentic Assistant')
 with st.form('login'):
  username=st.text_input('Username','procurement.manager');password=st.text_input('Password',type='password');submit=st.form_submit_button('Sign in',type='primary')
 if submit:
  u=api('POST','/auth/login',None,json={'username':username,'password':password})
  if u:st.session_state.user=u;st.rerun()
 with st.expander('Demo accounts'):
  st.markdown("Procurement Manager: `procurement.manager` / `ProcureDemo!26`\n\nOperations Manager: `operations.manager` / `OperateDemo!26`\n\nBusiness Admin: `business.admin` / `AdminDemo!26`\n\nAuditor: `auditor` / `AuditDemo!26")
 st.warning('Static demo credentials only; use enterprise SSO before production.');st.stop()
u=st.session_state.user;uname=u['username'];role=u['persona'];st.sidebar.success(role);st.sidebar.caption(uname);screen=st.sidebar.radio('Screens allowed for persona',SCREENS.get(role,[]))
if st.sidebar.button('Sign out'):st.session_state.user=None;st.rerun()
st.title('📊 Vendor Performance AI');st.caption(f'Persona-restricted workspace · {role}')
if screen=='Executive Dashboard':
 d=api('GET','/dashboard',uname)
 if d:
  a,b,c,e=st.columns(4);a.metric('Vendors in scope',d['vendor_count']);b.metric('Average score',d['average_score']);c.metric('Preferred',d['preferred']);e.metric('Needs action',d['needs_action'])
  l,r=st.columns(2)
  with l:
   x=pd.DataFrame(list(d['bands'].items()),columns=['Band','Count']);st.bar_chart(x.set_index('Band'))
  with r:
   x=pd.DataFrame(d['vendors']).sort_values('vendor_score').head(10);st.bar_chart(x.set_index('vendor_name')[['vendor_score']])
  with st.expander('MCP tool response'):
   x=api('GET','/mcp-summary',uname)
   if x:st.json(x)
elif screen=='Vendor Scorecard':
 d=api('GET','/scorecards',uname)
 if d is not None:
  x=pd.DataFrame(d);cols=['vendor_id','vendor_name','category','vendor_score','performance_band','delivery_score','quality_score','cost_score','consistency_score','risk_flags'];st.dataframe(x[[c for c in cols if c in x]],use_container_width=True)
  st.caption('Weights: delivery 35%, quality 30%, cost 20%, lead-time consistency 15%. Preferred >80; Monitor >60–80; Needs Action ≤60.')
elif screen=='Vendor Explorer':
 a,b,c=st.columns(3);cat=a.selectbox('Category',['','Packaging','Electronics','Raw Materials','Logistics','Maintenance','Office Supplies']);band=b.selectbox('Band',['','Preferred','Monitor','Needs Action']);score=c.slider('Minimum score',0,100,0)
 d=api('GET','/vendors',uname,params={'category':cat,'band':band,'min_score':score})
 if d is not None:
  x=pd.DataFrame(d);st.dataframe(x,use_container_width=True)
  if not x.empty:st.download_button('Export authorized vendor results',x.to_csv(index=False),'vendor_scores.csv','text/csv')
elif screen=='Agentic Recommendations':
 d=api('GET','/scorecards',uname)
 if d:
  x=pd.DataFrame(d).sort_values('vendor_score');choice=st.selectbox('Select vendor',x.apply(lambda r:f"{r.vendor_id} | {r.vendor_name} | score {r.vendor_score}",axis=1));vid=choice.split(' | ')[0]
  if st.button('Investigate and recommend',type='primary'):
   z=api('POST','/recommend',uname,json={'vendor_id':vid})
   if z:st.subheader('Agent recommendation');st.write(z['answer']);st.subheader('Vendor evidence');st.json(z['vendor']);st.subheader('Retrieved playbooks');st.dataframe(pd.DataFrame(z['evidence']),use_container_width=True)
elif screen=='Supplier AI Chat':
 q=st.text_area('Ask about supplier performance',placeholder='Which category has the weakest delivery performance?')
 if st.button('Ask assistant',type='primary',disabled=not q.strip()):
  d=api('POST','/chat',uname,json={'question':q})
  if d:st.write(d['answer'])
elif screen=='LLM Usage Dashboard':
 d=api('GET','/llm-usage',uname)
 if d:
  a,b,c,e=st.columns(4);a.metric('Requests',d['count']);b.metric('Input tokens',f"{d['input_tokens']:,}");c.metric('Output tokens',f"{d['output_tokens']:,}");e.metric('Estimated cost',f"${d['estimated_cost_usd']:.5f}");x=pd.DataFrame(d['records'])
  if not x.empty:x['day']=pd.to_datetime(x.ts).dt.date;st.line_chart(x.groupby('day').estimated_cost_usd.sum());st.dataframe(x,use_container_width=True)
  else:st.info('No LLM requests recorded yet.')
elif screen=='Access & Audit':
 d=api('GET','/audit',uname)
 if d is not None:st.dataframe(pd.DataFrame(d),use_container_width=True)
st.caption('Scores are decision-support signals. Validate source records and require human approval before vendor status or sourcing changes.')
