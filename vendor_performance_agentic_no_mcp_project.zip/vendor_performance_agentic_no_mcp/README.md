# Vendor Performance Agentic AI — No MCP, No LangChain

A modular Python prototype for supplier performance analytics. It separates Streamlit frontend, FastAPI backend, scoring/retrieval/recommendation agents, data services and telemetry. There is no MCP server/client and no LangChain dependency.

## Features
- Persona-based screen restrictions and category-based backend data scoping.
- Vendor scorecard weighted: delivery 35%, quality 30%, cost 20%, lead-time consistency 15%.
- Synthetic vendors, delivery, quality, invoice and lead-time datasets.
- ChromaDB retrieval for supplier performance playbooks, with keyword fallback.
- Optional OpenAI-powered recommendations and supplier chat.
- LLM usage dashboard and SQLite audit trail.

## Requirements
Use Python 3.10–3.12. Create a virtual environment.

### Windows PowerShell
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
$env:PYTHONPATH="."
```

### Start backend (Terminal 1)
```powershell
$env:PYTHONPATH="."
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload
```

### Start frontend (Terminal 2)
```powershell
$env:PYTHONPATH="."
streamlit run frontend/app.py --server.port 8501
```

API docs: http://127.0.0.1:8000/docs

## Demo accounts
- Procurement Manager: `procurement.manager` / `ProcureDemo!26`
- Operations Manager: `operations.manager` / `OperationsDemo!26`
- Business Admin: `admin` / `AdminDemo!26`
- Auditor: `auditor` / `AuditDemo!26`

## Optional OpenAI
Set `OPENAI_API_KEY` and optionally `OPENAI_MODEL` in the backend terminal before starting FastAPI. Without a key, the app returns fallback guidance and logs fallback events.

## Synthetic datasets
- `vendors.csv`: 30 vendors
- `delivery_logs.csv`: 1,200 delivery events
- `quality_inspections.csv`: 1,200 quality records
- `invoice_data.csv`: 1,200 invoice records
- `lead_time_logs.csv`: 1,200 lead-time records
- `supplier_playbooks.csv`: 5 playbooks

## Scorecard formula
Overall score = delivery 35% + quality 30% + cost 20% + lead-time consistency 15%. These are transparent prototype weights, not a trained predictive model.

## Security note
Demo credentials and the `X-Username` header are for local demonstration only. For production, use Entra ID/OIDC or another verified identity provider and enforce authorization using validated tokens. Update illustrative token cost rates to the actual model pricing. Require human review for contract, payment, and supplier-status decisions.
