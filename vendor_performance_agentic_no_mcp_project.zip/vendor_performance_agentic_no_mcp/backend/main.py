from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from shared.security import authenticate, user_context
from backend.services.data_service import vendors, delivery, quality, invoices, lead_times
from backend.services.telemetry import audit, usage, audits
from backend.agents.scoring_agent import run as score_vendors
from backend.agents.recommendation_agent import recommendation, chat
app = FastAPI(title="Vendor Performance Agentic AI API", version="1.0.0")
class LoginBody(BaseModel):
    username: str
    password: str
class VendorBody(BaseModel):
    vendor_id: str
class ChatBody(BaseModel):
    question: str
def current(x_username: str = Header(default="")):
    u = user_context(x_username)
    if not u: raise HTTPException(401, "Missing or invalid demo identity")
    return u
def require_screen(user, screen):
    if screen not in user["screens"]:
        raise HTTPException(403, f"Persona {user['persona']} cannot access {screen}")
def scoped_vendor_row(user, vendor_id):
    df = score_vendors(user)
    row = df[df.vendor_id == vendor_id]
    if row.empty: raise HTTPException(404, "Vendor not found in authorized scope")
    return row.iloc[0].to_dict()
@app.get("/health")
def health(): return {"status":"ok","service":"vendor-performance-api","mcp":False}
@app.post("/auth/login")
def login(body: LoginBody):
    u = authenticate(body.username, body.password)
    if not u: raise HTTPException(401, "Invalid username or password")
    audit(u, "login")
    return u
@app.get("/dashboard")
def dashboard(x_username: str = Header(default="")):
    u=current(x_username); require_screen(u,"Executive Dashboard")
    df=score_vendors(u)
    return {"vendors":len(df),"high_risk_vendors":int((df.overall_score<70).sum()),
        "average_score":round(float(df.overall_score.mean()),2) if len(df) else 0,
        "on_time_rate_pct":round(float(df.on_time_rate_pct.mean()),2) if len(df) else 0,
        "average_defect_rate_pct":round(float(df.avg_defect_rate_pct.mean()),2) if len(df) else 0,
        "annual_spend_usd":round(float(df.annual_spend_usd.sum()),2) if len(df) else 0}
@app.get("/scorecard")
def scorecard(x_username: str = Header(default="")):
    u=current(x_username); require_screen(u,"Vendor Scorecard")
    return score_vendors(u).to_dict("records")
@app.get("/vendors")
def vendor_list(x_username: str = Header(default="")):
    u=current(x_username); require_screen(u,"Vendor Explorer")
    return vendors(u).to_dict("records")
@app.get("/operational-data")
def operational_data(x_username: str = Header(default="")):
    u=current(x_username); require_screen(u,"Vendor Scorecard")
    return {"delivery":delivery(u).to_dict("records"),"quality":quality(u).to_dict("records"),
            "invoices":invoices(u).to_dict("records"),"lead_times":lead_times(u).to_dict("records")}
@app.post("/recommend")
def recommend(body: VendorBody, x_username: str = Header(default="")):
    u=current(x_username); require_screen(u,"Recommendations")
    if u["read_only"]: raise HTTPException(403,"Auditor persona is read-only")
    row=scoped_vendor_row(u,body.vendor_id)
    result=recommendation(row,u); audit(u,"vendor_recommendation",body.vendor_id)
    return {"vendor":row,**result}
@app.post("/chat")
def supplier_chat(body: ChatBody, x_username: str = Header(default="")):
    u=current(x_username); require_screen(u,"Supplier Chat")
    if u["read_only"]: raise HTTPException(403,"Auditor persona is read-only")
    df=score_vendors(u)
    summary={"vendor_count":len(df),"average_score":round(float(df.overall_score.mean()),2) if len(df) else 0,
             "high_risk_vendors":int((df.overall_score<70).sum()),
             "top_vendors":df.head(5)[["vendor_id","vendor_name","overall_score","risk_level"]].to_dict("records")}
    result=chat(body.question,u,summary); audit(u,"supplier_chat",body.question[:100])
    return result
@app.get("/llm-usage")
def llm_usage(x_username: str = Header(default="")):
    u=current(x_username); require_screen(u,"LLM Usage Dashboard")
    d=usage(u)
    return {"records":d.fillna("").to_dict("records"),"count":len(d),
        "input_tokens":int(d.input_tokens.sum()) if len(d) else 0,
        "output_tokens":int(d.output_tokens.sum()) if len(d) else 0,
        "estimated_cost":float(d.cost.sum()) if len(d) else 0}
@app.get("/audit")
def audit_log(x_username: str = Header(default="")):
    u=current(x_username); require_screen(u,"Access & Audit")
    return audits(u).fillna("").to_dict("records")
