from backend.services.data_service import scorecard
def run(user):
    df = scorecard(user)
    df["risk_level"] = df.overall_score.apply(lambda x: "Low" if x >= 85 else ("Medium" if x >= 70 else "High"))
    df["recommended_action"] = df.overall_score.apply(
        lambda x: "Maintain and monitor" if x >= 85 else ("Request improvement plan" if x >= 70 else "Escalate for supplier review"))
    return df
