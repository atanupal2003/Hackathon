import os, time
from backend.agents.retrieval_agent import retrieve
from backend.services.telemetry import log_llm
def call_llm(prompt, user, purpose):
    started = time.time()
    api_key = os.getenv("OPENAI_API_KEY", "")
    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    if not api_key:
        log_llm(user, "fallback", 0, 0, (time.time()-started)*1000, 0, "fallback", purpose)
        return ("LLM is not configured. Review the supplier scorecard, validate source records, "
                "request corrective-action evidence, and obtain human approval before changing contracts or payments.")
    try:
        from openai import OpenAI
        response = OpenAI(api_key=api_key).chat.completions.create(
            model=model, temperature=0.2,
            messages=[
                {"role":"system","content":"You are a supplier performance analyst. Use only supplied evidence, state uncertainty, do not claim fraud without proof, and recommend human review."},
                {"role":"user","content":prompt}
            ])
        inp = int(response.usage.prompt_tokens or 0)
        out = int(response.usage.completion_tokens or 0)
        # Illustrative rates only; configure actual rates for the chosen model.
        cost = inp * 0.00000015 + out * 0.00000060
        log_llm(user, model, inp, out, (time.time()-started)*1000, cost, "success", purpose)
        return response.choices[0].message.content or ""
    except Exception as e:
        log_llm(user, model, 0, 0, (time.time()-started)*1000, 0, "error", purpose)
        return f"LLM request failed: {e}"
def recommendation(vendor_row, user):
    evidence = retrieve(f"supplier performance delivery quality cost variance lead time {vendor_row.get('category','')}")
    prompt = f"Analyze this vendor scorecard, explain strengths and risks, suggest evidence-based next steps and KPIs. Do not make unsupported claims. Vendor: {vendor_row}. Playbooks: {evidence}"
    return {"answer": call_llm(prompt, user, "vendor_recommendation"), "evidence": evidence}
def chat(question, user, score_summary):
    evidence = retrieve(question)
    prompt = f"Answer the procurement question using only this scoped score summary and playbooks. Question: {question}; summary: {score_summary}; playbooks: {evidence}"
    return {"answer": call_llm(prompt, user, "supplier_chat"), "evidence": evidence}
