from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data"
def load(name):
    return pd.read_csv(DATA / name).fillna("")
def scoped(df, user):
    if "category" in df.columns:
        return df[df["category"].isin(user["categories"])].copy()
    return df.copy()
def vendors(user): return scoped(load("vendors.csv"), user)
def delivery(user):
    d = load("delivery_logs.csv").merge(load("vendors.csv")[["vendor_id","category"]], on="vendor_id", how="left")
    return scoped(d, user)
def quality(user):
    d = load("quality_inspections.csv").merge(load("vendors.csv")[["vendor_id","category"]], on="vendor_id", how="left")
    return scoped(d, user)
def invoices(user):
    d = load("invoice_data.csv").merge(load("vendors.csv")[["vendor_id","category"]], on="vendor_id", how="left")
    return scoped(d, user)
def lead_times(user):
    d = load("lead_time_logs.csv").merge(load("vendors.csv")[["vendor_id","category"]], on="vendor_id", how="left")
    return scoped(d, user)
def playbooks():
    return load("supplier_playbooks.csv").to_dict("records")
def scorecard(user):
    v = vendors(user)
    d = delivery(user); q = quality(user); inv = invoices(user); lt = lead_times(user)
    rows = []
    for _, vendor in v.iterrows():
        vid = vendor.vendor_id
        vd = d[d.vendor_id == vid]; vq = q[q.vendor_id == vid]
        vi = inv[inv.vendor_id == vid]; vl = lt[lt.vendor_id == vid]
        ontime = float(vd.on_time.mean()) if len(vd) else 0
        defect = float(vq.defect_rate.mean()) if len(vq) else 0
        costvar = float(vi.cost_variance_pct.abs().mean()) if len(vi) else 0
        leadvar = float(vl.lead_time_variance_days.std(ddof=0)) if len(vl) else 0
        # Normalize each criterion to 0..100; higher is better.
        delivery_score = max(0, min(100, ontime * 100))
        quality_score = max(0, min(100, (1 - defect) * 100))
        cost_score = max(0, min(100, 100 - costvar * 2.0))
        consistency_score = max(0, min(100, 100 - leadvar * 5.0))
        overall = round(.35*delivery_score + .30*quality_score + .20*cost_score + .15*consistency_score, 2)
        rows.append({
            "vendor_id": vid, "vendor_name": vendor.vendor_name, "category": vendor.category,
            "region": vendor.region, "contract_status": vendor.contract_status,
            "annual_spend_usd": float(vendor.annual_spend_usd),
            "delivery_score": round(delivery_score,2), "quality_score": round(quality_score,2),
            "cost_score": round(cost_score,2), "lead_time_consistency_score": round(consistency_score,2),
            "overall_score": overall, "on_time_rate_pct": round(ontime*100,2),
            "avg_defect_rate_pct": round(defect*100,2), "avg_abs_cost_variance_pct": round(costvar,2),
            "lead_time_std_days": round(leadvar,2), "delivery_records": int(len(vd)),
            "quality_records": int(len(vq)), "invoice_records": int(len(vi))
        })
    return pd.DataFrame(rows).sort_values("overall_score", ascending=False)
