import os, requests, pandas as pd, streamlit as st
API=os.getenv("VENDOR_API_URL","http://127.0.0.1:8000")
SCREENS={
"Procurement Manager":["Executive Dashboard","Vendor Scorecard","Vendor Explorer","Recommendations","Supplier Chat","LLM Usage Dashboard"],
"Operations Manager":["Executive Dashboard","Vendor Scorecard","Vendor Explorer","Recommendations","Supplier Chat"],
"Business Admin":["Executive Dashboard","Vendor Scorecard","Vendor Explorer","Recommendations","Supplier Chat","LLM Usage Dashboard","Access & Audit"],
"Auditor":["Executive Dashboard","Vendor Scorecard","Vendor Explorer","LLM Usage Dashboard","Access & Audit"]}
st.set_page_config(page_title="Vendor Performance Agentic AI",page_icon="📊",layout="wide")
def api(method,path,username=None,**kwargs):
    headers=kwargs.pop("headers",{})
    if username: headers["X-Username"]=username
    try:
        r=requests.request(method,API+path,headers=headers,timeout=90,**kwargs)
        if not r.ok:
            st.error(f"Backend {r.status_code}: {r.text}")
            return None
        return r.json()
    except Exception as e:
        st.error(f"Backend unavailable: {e}")
        return None
if "user" not in st.session_state: st.session_state.user=None
st.sidebar.title("📊 Vendor Performance AI")
if not st.session_state.user:
    st.title("Vendor Performance Agentic AI")
    st.write("Supplier scorecards combining delivery reliability, quality, invoice variance and lead-time consistency.")
    with st.form("login"):
        username=st.text_input("Username","procurement.manager")
        password=st.text_input("Password",type="password")
        submit=st.form_submit_button("Sign in")
    if submit:
        u=api("POST","/auth/login",json={"username":username,"password":password})
        if u: st.session_state.user=u; st.rerun()
    with st.expander("Demo accounts"):
        st.write("Procurement Manager: procurement.manager / ProcureDemo!26")
        st.write("Operations Manager: operations.manager / OperationsDemo!26")
        st.write("Business Admin: admin / AdminDemo!26")
        st.write("Auditor: auditor / AuditDemo!26")
    st.stop()
user=st.session_state.user; username=user["username"]; persona=user["persona"]
st.sidebar.success(persona)
screen=st.sidebar.radio("Authorized screens",SCREENS.get(persona,["Executive Dashboard"]))
if st.sidebar.button("Sign out"): st.session_state.user=None; st.rerun()
st.title("📊 Vendor Performance Agentic AI")
st.caption(f"Persona-restricted workspace · {persona} · Synthetic data")
if screen=="Executive Dashboard":
    d=api("GET","/dashboard",username)
    if d:
        cols=st.columns(4)
        cols[0].metric("Vendors",d["vendors"]); cols[1].metric("High-risk vendors",d["high_risk_vendors"])
        cols[2].metric("Average score",f"{d['average_score']:.1f}/100")
        cols[3].metric("On-time delivery",f"{d['on_time_rate_pct']:.1f}%")
        c1,c2=st.columns(2); c1.metric("Average defect rate",f"{d['average_defect_rate_pct']:.2f}%")
        c2.metric("Annual vendor spend",f"${d['annual_spend_usd']:,.0f}")
elif screen=="Vendor Scorecard":
    d=api("GET","/scorecard",username)
    if d:
        df=pd.DataFrame(d); st.bar_chart(df.set_index("vendor_name")[["delivery_score","quality_score","cost_score","lead_time_consistency_score"]])
        st.dataframe(df,use_container_width=True)
        st.download_button("Download scorecard CSV",df.to_csv(index=False),"vendor_scorecard.csv","text/csv")
elif screen=="Vendor Explorer":
    d=api("GET","/vendors",username)
    if d:
        df=pd.DataFrame(d); st.dataframe(df,use_container_width=True)
        st.download_button("Download vendors CSV",df.to_csv(index=False),"vendors.csv","text/csv")
elif screen=="Recommendations":
    d=api("GET","/scorecard",username)
    if d:
        df=pd.DataFrame(d)
        chosen=st.selectbox("Choose vendor",df.apply(lambda r:f"{r.vendor_id} | {r.vendor_name} | score {r.overall_score}",axis=1))
        if st.button("Generate evidence-based recommendation",type="primary"):
            result=api("POST","/recommend",username,json={"vendor_id":chosen.split(" | ")[0]})
            if result:
                st.subheader("Recommendation"); st.write(result["answer"])
                st.subheader("Vendor scorecard"); st.json(result["vendor"])
                st.subheader("Retrieved playbooks"); st.dataframe(pd.DataFrame(result["evidence"]),use_container_width=True)
elif screen=="Supplier Chat":
    question=st.text_area("Ask about vendor performance, delivery, quality, invoice variance or lead-time consistency")
    if st.button("Ask assistant",disabled=not question.strip()):
        result=api("POST","/chat",username,json={"question":question})
        if result:
            st.write(result["answer"])
            with st.expander("Retrieved evidence"): st.dataframe(pd.DataFrame(result["evidence"]),use_container_width=True)
elif screen=="LLM Usage Dashboard":
    d=api("GET","/llm-usage",username)
    if d:
        c=st.columns(4); c[0].metric("Requests",d["count"]); c[1].metric("Input tokens",d["input_tokens"])
        c[2].metric("Output tokens",d["output_tokens"]); c[3].metric("Estimated cost",f"${d['estimated_cost']:.5f}")
        df=pd.DataFrame(d["records"])
        if len(df):
            df["day"]=pd.to_datetime(df.ts).dt.date
            st.line_chart(df.groupby("day").cost.sum())
            st.dataframe(df,use_container_width=True)
        else: st.info("No LLM calls recorded yet. Run a recommendation or chat request.")
elif screen=="Access & Audit":
    d=api("GET","/audit",username)
    if d is not None: st.dataframe(pd.DataFrame(d),use_container_width=True)
st.caption("Prototype uses synthetic data. Validate supplier evidence and require human approval before contract, payment or supplier-status decisions.")
