PERSONAS = {
    "Procurement Manager": {
        "username": "procurement.manager", "password": "ProcureDemo!26",
        "screens": ["Executive Dashboard", "Vendor Scorecard", "Vendor Explorer", "Recommendations", "Supplier Chat", "LLM Usage Dashboard"],
        "categories": ["Packaging", "Food Ingredients", "Logistics", "Machinery", "Cleaning Supplies", "IT Services"],
        "read_only": False
    },
    "Operations Manager": {
        "username": "operations.manager", "password": "OperationsDemo!26",
        "screens": ["Executive Dashboard", "Vendor Scorecard", "Vendor Explorer", "Recommendations", "Supplier Chat"],
        "categories": ["Packaging", "Food Ingredients", "Logistics", "Machinery"],
        "read_only": False
    },
    "Business Admin": {
        "username": "admin", "password": "AdminDemo!26",
        "screens": ["Executive Dashboard", "Vendor Scorecard", "Vendor Explorer", "Recommendations", "Supplier Chat", "LLM Usage Dashboard", "Access & Audit"],
        "categories": ["Packaging", "Food Ingredients", "Logistics", "Machinery", "Cleaning Supplies", "IT Services"],
        "read_only": False
    },
    "Auditor": {
        "username": "auditor", "password": "AuditDemo!26",
        "screens": ["Executive Dashboard", "Vendor Scorecard", "Vendor Explorer", "LLM Usage Dashboard", "Access & Audit"],
        "categories": ["Packaging", "Food Ingredients", "Logistics", "Machinery", "Cleaning Supplies", "IT Services"],
        "read_only": True
    }
}
def authenticate(username, password):
    for persona, cfg in PERSONAS.items():
        if cfg["username"] == username and cfg["password"] == password:
            return {"username": username, "persona": persona, "screens": cfg["screens"],
                    "categories": cfg["categories"], "read_only": cfg["read_only"]}
    return None
def user_context(username):
    for persona, cfg in PERSONAS.items():
        if cfg["username"] == username:
            return {"username": username, "persona": persona, "screens": cfg["screens"],
                    "categories": cfg["categories"], "read_only": cfg["read_only"]}
    return None
