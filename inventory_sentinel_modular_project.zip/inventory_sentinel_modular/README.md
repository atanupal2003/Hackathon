# Inventory Sentinel AI — Modular Python Project

## Components
- `frontend/app.py`: Streamlit UI; only displays screens allowed for the signed-in persona.
- `backend/main.py`: FastAPI REST backend; validates identity, enforces persona scope and exposes APIs.
- `backend/agents/`: detection, investigation, retrieval and chat agents.
- `mcp_server/server.py`: separate MCP server using Streamable HTTP on port 8001.
- `backend/mcp_client.py`: backend MCP client.
- `shared/security.py`: demo persona mapping.
- `data/`: synthetic CSV datasets.
- SQLite: LLM usage and audit telemetry; ChromaDB: persistent incident vector store.

## Architecture
Browser → Streamlit :8501 → FastAPI :8000 → Agents / ChromaDB / SQLite
FastAPI → MCP client → MCP server :8001/mcp

## Setup (Python 3.10–3.12 recommended)
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:PYTHONPATH="."
```
Open three terminals in the project root.

Terminal 1 — MCP server:
```powershell
$env:PYTHONPATH="."
python -m mcp_server.server
```
Terminal 2 — backend:
```powershell
$env:PYTHONPATH="."
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload
```
Terminal 3 — frontend:
```powershell
$env:PYTHONPATH="."
streamlit run frontend/app.py --server.port 8501
```
Open the Streamlit URL shown in the terminal. Backend API docs: http://127.0.0.1:8000/docs.

## Demo accounts and screen restrictions
- Store Manager: `store.manager` / `StoreDemo!26` — Dashboard, Anomaly Explorer, Chat.
- Warehouse Supervisor: `warehouse.supervisor` / `WarehouseDemo!26` — Dashboard, Explorer, Investigation, Chat.
- Loss Prevention Analyst: `loss.analyst` / `LossDemo!26` — Dashboard, Explorer, Investigation, Chat, LLM Usage.
- Administrator: `admin` / `AdminDemo!26` — all screens, including Access & Audit.

Screen hiding is a UX restriction only. The backend also filters inventory rows by assigned store/warehouse before rendering, exporting, aggregating, or prompting the LLM. The demo uses an `X-Username` header and static credentials only for local testing. **Do not deploy as-is**: use Entra ID/OIDC/JWT validation, trusted group claims, secure service-to-service auth, secrets management, and production database policies.

## Optional LLM
Set in the backend terminal before starting backend:
```powershell
$env:OPENAI_API_KEY="your-key"
$env:OPENAI_MODEL="gpt-4o-mini"
```
Without a key, investigation/chat uses fallback text and logs a fallback event. The included cost rate is illustrative and must be updated for actual provider/model pricing.

## MCP tools
- `inventory_summary(username)`: scoped summary for the mapped demo user.
- `search_incident_playbooks(query, category)`: searches synthetic incident playbooks.
MCP server availability can be checked in the dashboard expander. ChromaDB may initialize/download an embedding model on first use; keyword fallback is included.

## Notes
The project is a hackathon MVP. Synthetic data and anomaly flags are not proof of theft. Validate model precision/recall with reviewed cases before real operational use.
