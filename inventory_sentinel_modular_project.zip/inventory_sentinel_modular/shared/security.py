PERSONAS = {
 "Store Manager": {"username":"store.manager","password":"StoreDemo!26","stores":["STORE-001","STORE-002"],"warehouses":[],"screens":["Executive Dashboard","Anomaly Explorer","Inventory AI Chat"]},
 "Warehouse Supervisor": {"username":"warehouse.supervisor","password":"WarehouseDemo!26","stores":[],"warehouses":["WH-01","WH-02"],"screens":["Executive Dashboard","Anomaly Explorer","Agentic Investigation","Inventory AI Chat"]},
 "Loss Prevention Analyst": {"username":"loss.analyst","password":"LossDemo!26","stores":[f"STORE-{i:03d}" for i in range(1,9)],"warehouses":[f"WH-{i:02d}" for i in range(1,4)],"screens":["Executive Dashboard","Anomaly Explorer","Agentic Investigation","Inventory AI Chat","LLM Usage Dashboard"]},
 "Administrator": {"username":"admin","password":"AdminDemo!26","stores":[f"STORE-{i:03d}" for i in range(1,9)],"warehouses":[f"WH-{i:02d}" for i in range(1,4)],"screens":["Executive Dashboard","Anomaly Explorer","Agentic Investigation","Inventory AI Chat","LLM Usage Dashboard","Access & Audit"]},
}
def authenticate(username,password):
    for persona,r in PERSONAS.items():
        if r["username"]==username and r["password"]==password:
            return {"username":username,"persona":persona,"stores":r["stores"],"warehouses":r["warehouses"],"screens":r["screens"]}
    return None
def user_context(username):
    for persona,r in PERSONAS.items():
        if r["username"]==username:
            return {"username":username,"persona":persona,"stores":r["stores"],"warehouses":r["warehouses"],"screens":r["screens"]}
    return None
