$env:PYTHONPATH="."
streamlit run frontend/app.py --server.port 8501
