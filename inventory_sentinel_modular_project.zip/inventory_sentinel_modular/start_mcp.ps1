$env:PYTHONPATH="."
python -m mcp_server.server
