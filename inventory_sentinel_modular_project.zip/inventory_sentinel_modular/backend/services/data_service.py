from pathlib import Path
import pandas as pd
from sklearn.ensemble import IsolationForest
ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/"data"
FEATURES=["variance_qty","shrinkage_pct","transaction_velocity","scan_count","received_qty","sold_qty"]
def load_inventory():
    df=pd.read_csv(DATA/"inventory_daily.csv",parse_dates=["date"])
    required={"store_id","warehouse_id","category","product_id",*FEATURES}
    missing=required-set(df.columns)
    if missing: raise ValueError(f"Missing columns: {sorted(missing)}")
    return df
def scope(df,user):
    if user["persona"]=="Store Manager": return df[df.store_id.isin(user["stores"])].copy()
    if user["persona"]=="Warehouse Supervisor": return df[df.warehouse_id.isin(user["warehouses"])].copy()
    return df[df.store_id.isin(user["stores"]) & df.warehouse_id.isin(user["warehouses"])].copy()
def detect(df):
    df=df.copy()
    if df.empty:
        df["anomaly_score"]=[]; df["is_anomaly"]=[]; df["rule_flag"]=[]
        return df
    x=df[FEATURES].replace([float("inf"),float("-inf")],0).fillna(0)
    if len(x)>=20:
        model=IsolationForest(n_estimators=120,contamination=.045,random_state=42).fit(x)
        df["anomaly_score"]=-model.decision_function(x); df["is_anomaly"]=model.predict(x)==-1
    else:
        df["anomaly_score"]=0.0; df["is_anomaly"]=False
    df["rule_flag"]=(df.variance_qty<=-15)|((df.scan_count<=1)&(df.variance_qty < -5))
    df["is_anomaly"]=df.is_anomaly|df.rule_flag
    return df
def authorized_inventory(user): return detect(scope(load_inventory(),user))
def load_incidents(): return pd.read_csv(DATA/"historical_incidents.csv").fillna("").to_dict("records")
