import asyncio, json, os
async def _call(name,args):
    from mcp import ClientSession
    from mcp.client.streamable_http import streamablehttp_client
    async with streamablehttp_client(os.getenv("MCP_SERVER_URL","http://127.0.0.1:8001/mcp")) as (read,write,_):
        async with ClientSession(read,write) as session:
            await session.initialize()
            result=await session.call_tool(name,arguments=args)
            structured=getattr(result,"structuredContent",None)
            if structured is not None: return structured
            texts=[getattr(c,"text","") for c in (getattr(result,"content",[]) or [])]
            if len(texts)==1:
                try: return json.loads(texts[0])
                except Exception: return texts[0]
            return texts
def call(name,args): return asyncio.run(_call(name,args))
