from backend.services.data_service import authorized_inventory
def run(user):
    df=authorized_inventory(user); flags=df[df.is_anomaly].sort_values("anomaly_score",ascending=False)
    return {"df":df,"flags":flags,"total":len(df),"count":len(flags),"rate":round(float(df.is_anomaly.mean()*100),2) if len(df) else 0,"negative_units":int(abs(df.loc[df.variance_qty<0,"variance_qty"].sum()))}
