from pathlib import Path
from backend.services.data_service import load_incidents
ROOT=Path(__file__).resolve().parents[2]
def retrieve(query,category="",k=3):
    items=load_incidents()
    try:
        import chromadb
        client=chromadb.PersistentClient(path=str(ROOT/"chroma_store"))
        col=client.get_or_create_collection("inventory_playbooks")
        if col.count()==0 and items:
            docs=[" ".join(str(x.get(k,"")) for k in ["title","category","symptoms","likely_cause","recommended_action"]) for x in items]
            col.add(ids=[x["incident_id"] for x in items],documents=docs,metadatas=[{"category":x["category"],"severity":x["severity"]} for x in items])
        if col.count():
            args={"query_texts":[query],"n_results":min(k,col.count())}
            if category: args["where"]={"category":category}
            ids=col.query(**args)["ids"][0]
            return [x for x in items if x["incident_id"] in ids]
    except Exception: pass
    terms=[t for t in query.lower().split() if len(t)>3]
    scored=[]
    for x in items:
        if category and x["category"]!=category: continue
        txt=" ".join(map(str,x.values())).lower()
        scored.append((sum(t in txt for t in terms),x))
    return [x for _,x in sorted(scored,key=lambda z:z[0],reverse=True)[:k]]
