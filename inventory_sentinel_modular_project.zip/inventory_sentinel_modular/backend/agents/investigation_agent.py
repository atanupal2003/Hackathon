import os,time
from backend.agents.retrieval_agent import retrieve
from backend.services.telemetry import llm_log
def _generate(prompt,user,purpose):
    start=time.time(); key=os.getenv("OPENAI_API_KEY",""); model=os.getenv("OPENAI_MODEL","gpt-4o-mini")
    if not key:
        llm_log(user,"fallback","none",0,0,(time.time()-start)*1000,0,"fallback",purpose)
        return "LLM is not configured. Validate the physical count, receiving records, POS movements and scan logs. Treat this as an investigation lead, not proof of theft."
    try:
        from openai import OpenAI
        resp=OpenAI(api_key=key).chat.completions.create(model=model,temperature=.2,messages=[
          {"role":"system","content":"You are a careful inventory analyst. Use only supplied evidence, state uncertainty, never assert theft as fact, and recommend human-reviewed checks."},
          {"role":"user","content":prompt}])
        ins=int(getattr(resp.usage,"prompt_tokens",0) or 0); outs=int(getattr(resp.usage,"completion_tokens",0) or 0)
        cost=ins*.00000015+outs*.00000060
        llm_log(user,model,"OpenAI",ins,outs,(time.time()-start)*1000,cost,"success",purpose)
        return resp.choices[0].message.content or ""
    except Exception as e:
        llm_log(user,model,"OpenAI",0,0,(time.time()-start)*1000,0,"error",purpose)
        return f"LLM request failed: {e}"
def investigate(record,user):
    q=f"{record.get('category')} variance {record.get('variance_qty')} shrinkage {record.get('shrinkage_pct')} velocity {record.get('transaction_velocity')} scan {record.get('scan_count')}"
    evidence=retrieve(q,record.get("category",""))
    prompt=f"Investigate this synthetic inventory anomaly. Explain why flagged, possible causes, evidence to collect, next steps, confidence and limitations. Do not assert theft. Record={record}; playbooks={evidence}"
    return {"answer":_generate(prompt,user,"investigation"),"evidence":evidence}
def chat(question,user,aggregates):
    prompt=f"Answer only from these authorized aggregates. State limitations. Question={question}; aggregates={aggregates}"
    return _generate(prompt,user,"chat")
