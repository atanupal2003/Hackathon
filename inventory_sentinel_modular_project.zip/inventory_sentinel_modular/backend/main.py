from fastapi import FastAPI,Header,HTTPException
from pydantic import BaseModel
from shared.security import authenticate,user_context
from backend.agents.detection_agent import run
from backend.agents.investigation_agent import investigate,chat
from backend.services.telemetry import audit,usage,audit_rows

app=FastAPI(title="Inventory Sentinel Backend API",version="1.0")
class Login(BaseModel): username:str; password:str
class Chat(BaseModel): question:str
class Investigate(BaseModel): record_index:int
def current(x_username:str=Header(default="")):
    user=user_context(x_username)
    if not user: raise HTTPException(401,"Missing or invalid demo identity")
    return user
def require_screen(user, screen):
    if screen not in user["screens"]:
        raise HTTPException(403, f"Persona '{user['persona']}' is not authorized for screen: {screen}")
@app.get("/health")
def health(): return {"status":"ok","service":"backend"}
@app.post("/auth/login")
def login(body:Login):
    user=authenticate(body.username,body.password)
    if not user: raise HTTPException(401,"Invalid username/password")
    audit(user,"login","demo sign-in"); return user
@app.get("/dashboard")
def dashboard(x_username:str=Header(default="")):
    user=current(x_username); require_screen(user,"Executive Dashboard"); r=run(user); df=r["df"]
    trend=df.assign(day=df.date.dt.strftime("%Y-%m-%d")).groupby("day").agg(total=("product_id","count"),anomalies=("is_anomaly","sum")).reset_index()
    return {"persona":user["persona"],"total_records":r["total"],"flagged_count":r["count"],"flag_rate_pct":r["rate"],"negative_variance_units":r["negative_units"],"trend":trend.to_dict("records"),"by_category":df[df.is_anomaly].groupby("category").size().to_dict(),"by_store":df[df.is_anomaly].groupby("store_id").size().to_dict()}
@app.get("/anomalies")
def anomalies(category:str="",store_id:str="",min_score:float=-1,x_username:str=Header(default="")):
    user=current(x_username); require_screen(user,"Anomaly Explorer"); df=run(user)["flags"]
    df=df[df.anomaly_score>=min_score]
    if category: df=df[df.category==category]
    if store_id: df=df[df.store_id==store_id]
    df=df.sort_values("anomaly_score",ascending=False).head(500).copy(); df["date"]=df.date.astype(str)
    return df.to_dict("records")
@app.post("/investigate")
def investigate_api(body:Investigate,x_username:str=Header(default="")):
    user=current(x_username); require_screen(user,"Agentic Investigation"); df=run(user)["flags"].reset_index(drop=True)
    if body.record_index<0 or body.record_index>=min(len(df),500): raise HTTPException(404,"Anomaly index not found in authorized scope")
    row=df.iloc[body.record_index].to_dict(); row["date"]=str(row.get("date",""))
    result=investigate(row,user); audit(user,"investigation",f"{row.get('store_id')} {row.get('category')} variance={row.get('variance_qty')}")
    return {"record":row,**result}
@app.post("/chat")
def chat_api(body:Chat,x_username:str=Header(default="")):
    user=current(x_username); require_screen(user,"Inventory AI Chat")
    if not body.question.strip(): raise HTTPException(400,"Question cannot be empty")
    df=run(user)["df"]
    ag=df.groupby("category").agg(records=("product_id","count"),anomalies=("is_anomaly","sum"),net_variance=("variance_qty","sum"),negative_units=("variance_qty",lambda x:int(abs(x[x<0].sum())))).reset_index().to_dict("records")
    answer=chat(body.question,user,ag); audit(user,"chat_query",body.question[:200]); return {"answer":answer}
@app.get("/llm-usage")
def llm_usage(x_username:str=Header(default="")):
    user=current(x_username); require_screen(user,"LLM Usage Dashboard"); df=usage(user)
    return {"records":df.fillna("").to_dict("records"),"count":len(df),"input_tokens":int(df.input_tokens.sum()) if len(df) else 0,"output_tokens":int(df.output_tokens.sum()) if len(df) else 0,"estimated_cost_usd":float(df.estimated_cost_usd.sum()) if len(df) else 0}
@app.get("/audit")
def audit_api(x_username:str=Header(default="")):
    user=current(x_username)
    require_screen(user,"Access & Audit")
    return audit_rows(user).fillna("").to_dict("records")
@app.get("/mcp-summary")
def mcp_summary(x_username:str=Header(default="")):
    user=current(x_username)
    try:
        from backend.mcp_client import call
        return call("inventory_summary",{"username":user["username"]})
    except Exception as e: raise HTTPException(503,f"MCP server unavailable: {e}")
