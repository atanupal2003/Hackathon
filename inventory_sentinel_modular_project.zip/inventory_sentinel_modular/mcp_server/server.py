"""Separate MCP server (Streamable HTTP transport)."""
from mcp.server.fastmcp import FastMCP
mcp=FastMCP("inventory-sentinel",host="127.0.0.1",port=8001,stateless_http=True)
@mcp.tool()
def inventory_summary(username:str)->dict:
    """Return inventory KPIs for the given demo username, restricted to its assigned persona scope."""
    from shared.security import user_context
    from backend.agents.detection_agent import run
    user=user_context(username)
    if not user: return {"error":"unknown user"}
    r=run(user)
    return {"persona":user["persona"],"total_records":r["total"],"flagged_count":r["count"],"flag_rate_pct":r["rate"]}
@mcp.tool()
def search_incident_playbooks(query:str,category:str="")->list:
    """Search synthetic incident playbooks for a relevant category and query."""
    from backend.agents.retrieval_agent import retrieve
    return retrieve(query,category,k=3)
if __name__=="__main__": mcp.run(transport="streamable-http")
