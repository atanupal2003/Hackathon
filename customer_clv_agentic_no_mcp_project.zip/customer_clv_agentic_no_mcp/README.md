# Customer Lifetime Value Agentic AI — No MCP, No LangChain

Python 3.10–3.12 recommended. Modular Streamlit frontend, FastAPI backend, native Python agents, ChromaDB RAG and optional OpenAI LLM. No MCP server and no LangChain dependencies.

## Install (PowerShell)
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```
Start backend in terminal 1:
```powershell
.venv\Scripts\Activate.ps1
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload
```
Start frontend in terminal 2:
```powershell
.venv\Scripts\Activate.ps1
streamlit run frontend/app.py --server.port 8501
```
API docs: http://127.0.0.1:8000/docs. There is no MCP server to start.

## Demo accounts
- Marketing Analyst: `marketing.analyst` / `MarketDemo!26`
- CRM Manager: `crm.manager` / `CRMDemo!26`
- Regional Manager: `regional.manager` / `RegionDemo!26`
- Administrator: `admin` / `AdminDemo!26`

Regional Manager is scoped to East and South. Static credentials and username headers are local-demo only; production should use verified Entra ID/OIDC tokens.

## Synthetic data
`data/customers.csv` contains 600 profiles and a synthetic future 12-month value target. `data/purchase_history.csv` contains 2,400 purchase transactions. `data/marketing_playbooks.csv` contains retention playbooks.

## CLV model
HistGradientBoostingRegressor estimates synthetic future 12-month value and reports holdout MAE/RMSE. Metrics on synthetic targets validate pipeline mechanics only, not real-world accuracy.

## ChromaDB / LLM
ChromaDB persists playbooks in `chroma_store/`; keyword fallback is included if embeddings are unavailable. Optional OpenAI: set `OPENAI_API_KEY` and optionally `OPENAI_MODEL` in the backend terminal. Without a key, fallback responses are logged. Cost estimates use illustrative rates and must be updated.

## Security and responsible use
Screen access is checked server-side; regional rows are filtered. Demo auth is not production security. Respect consent and unsubscribe rules, avoid sensitive-attribute targeting, and use controlled experiments to measure campaign impact.
