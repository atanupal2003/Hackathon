PERSONAS={
"Marketing Analyst":{"username":"marketing.analyst","password":"MarketDemo!26","locations":["North","South","East","West","Central"],"screens":["Executive Dashboard","Customer Explorer","CLV Predictions","Customer AI Assistant"]},
"CRM Manager":{"username":"crm.manager","password":"CRMDemo!26","locations":["North","South","East","West","Central"],"screens":["Executive Dashboard","Customer Explorer","CLV Predictions","Retention Recommendations","Customer AI Assistant","LLM Usage Dashboard"]},
"Regional Manager":{"username":"regional.manager","password":"RegionDemo!26","locations":["East","South"],"screens":["Executive Dashboard","Customer Explorer","CLV Predictions","Retention Recommendations"]},
"Administrator":{"username":"admin","password":"AdminDemo!26","locations":["North","South","East","West","Central"],"screens":["Executive Dashboard","Customer Explorer","CLV Predictions","Retention Recommendations","Customer AI Assistant","LLM Usage Dashboard","Access & Audit"]}}
def authenticate(username,password):
 for p,r in PERSONAS.items():
  if r["username"]==username and r["password"]==password:return {"username":username,"persona":p,"locations":r["locations"],"screens":r["screens"]}
 return None
def user_context(username):
 for p,r in PERSONAS.items():
  if r["username"]==username:return {"username":username,"persona":p,"locations":r["locations"],"screens":r["screens"]}
 return None
