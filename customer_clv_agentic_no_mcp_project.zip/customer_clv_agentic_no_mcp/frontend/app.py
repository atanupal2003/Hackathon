import os,requests,pandas as pd,streamlit as st
API=os.getenv("CLV_API_URL","http://127.0.0.1:8000")
SCREENS={"Marketing Analyst":["Executive Dashboard","Customer Explorer","CLV Predictions","Customer AI Assistant"],"CRM Manager":["Executive Dashboard","Customer Explorer","CLV Predictions","Retention Recommendations","Customer AI Assistant","LLM Usage Dashboard"],"Regional Manager":["Executive Dashboard","Customer Explorer","CLV Predictions","Retention Recommendations"],"Administrator":["Executive Dashboard","Customer Explorer","CLV Predictions","Retention Recommendations","Customer AI Assistant","LLM Usage Dashboard","Access & Audit"]}
st.set_page_config(page_title="Customer CLV AI",page_icon="💎",layout="wide")
def api(method,path,user=None,**kw):
 h=kw.pop("headers",{})
 if user:h["X-Username"]=user
 try:
  r=requests.request(method,API+path,headers=h,timeout=120,**kw)
  if not r.ok:st.error(f"Backend {r.status_code}: {r.text}");return None
  return r.json()
 except Exception as e:st.error(f"Backend unavailable: {e}");return None
if "user" not in st.session_state:st.session_state.user=None
st.sidebar.title("💎 Customer CLV AI")
if not st.session_state.user:
 st.title("Customer Lifetime Value Prediction")
 with st.form("login"):
  name=st.text_input("Username","crm.manager");pwd=st.text_input("Password",type="password");go=st.form_submit_button("Sign in")
 if go:
  u=api("POST","/auth/login",json={"username":name,"password":pwd})
  if u:st.session_state.user=u;st.rerun()
 with st.expander("Demo accounts"):
  st.write("Marketing Analyst: marketing.analyst / MarketDemo!26")
  st.write("CRM Manager: crm.manager / CRMDemo!26")
  st.write("Regional Manager: regional.manager / RegionDemo!26")
  st.write("Administrator: admin / AdminDemo!26")
 st.stop()
u=st.session_state.user;name=u["username"];p=u["persona"];st.sidebar.success(p)
screen=st.sidebar.radio("Authorized screens",SCREENS[p])
if st.sidebar.button("Sign out"):st.session_state.user=None;st.rerun()
st.title("💎 Customer Lifetime Value AI");st.caption(f"Persona-restricted workspace · {p}")
if screen=="Executive Dashboard":
 d=api("GET","/dashboard",name)
 if d:
  a,b,c,e=st.columns(4);a.metric("Customers",d["customer_count"]);b.metric("Average predicted CLV",f"${d['average_clv']:,.2f}");c.metric("High value",d["high_value"]);e.metric("Low value",d["low_value"])
  x=pd.DataFrame(list(d["segments"].items()),columns=["Segment","Customers"])
  if not x.empty:st.bar_chart(x.set_index("Segment"))
  st.subheader("Holdout model metrics");st.json(d["metrics"])
elif screen=="Customer Explorer":
 a,b=st.columns(2);seg=a.selectbox("Segment",["","High Value","Mid Value","Low Value"]);q=b.text_input("Customer ID or location")
 d=api("GET","/customers",name,params={"segment":seg,"q":q})
 if d is not None:
  df=pd.DataFrame(d);st.dataframe(df,use_container_width=True)
  if len(df):st.download_button("Export scoped customers",df.to_csv(index=False),"customer_clv.csv","text/csv")
elif screen=="CLV Predictions":
 d=api("GET","/predictions",name)
 if d:
  st.json(d["metrics"]);df=pd.DataFrame(d["records"]);st.dataframe(df,use_container_width=True)
  if len(df):st.download_button("Download predictions",df.to_csv(index=False),"clv_predictions.csv","text/csv")
elif screen=="Retention Recommendations":
 d=api("GET","/predictions",name)
 if d and d["records"]:
  df=pd.DataFrame(d["records"]);choice=st.selectbox("Customer",df.apply(lambda x:f"{x.customer_id} | {x.clv_segment} | ${x.predicted_clv_12m:,.0f}",axis=1));cid=choice.split(" | ")[0]
  if st.button("Generate recommendation"):
   out=api("POST","/recommend",name,json={"customer_id":cid})
   if out:st.write(out["answer"]);st.json(out["customer"]);st.dataframe(pd.DataFrame(out["evidence"]))
elif screen=="Customer AI Assistant":
 q=st.text_area("Ask a customer value or retention question")
 if st.button("Ask assistant",disabled=not q.strip()):
  d=api("POST","/chat",name,json={"question":q})
  if d:st.write(d["answer"])
elif screen=="LLM Usage Dashboard":
 d=api("GET","/llm-usage",name)
 if d:
  a,b,c,e=st.columns(4);a.metric("Requests",d["count"]);b.metric("Input tokens",d["input_tokens"]);c.metric("Output tokens",d["output_tokens"]);e.metric("Estimated cost",f"${d['cost']:.5f}")
  df=pd.DataFrame(d["records"])
  if len(df):df["day"]=pd.to_datetime(df.ts).dt.date;st.line_chart(df.groupby("day").cost.sum());st.dataframe(df,use_container_width=True)
  else:st.info("No LLM calls yet.")
elif screen=="Access & Audit":
 d=api("GET","/audit",name)
 if d is not None:st.dataframe(pd.DataFrame(d),use_container_width=True)
st.caption("Synthetic-data MVP. Predictions are estimates; respect consent and measure campaign uplift with control groups.")
