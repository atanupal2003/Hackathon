import numpy as np,pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error,mean_squared_error
from backend.services.data_service import customers
FEATURES=["age","tenure_months","purchase_frequency_monthly","average_order_value","total_spend","purchase_count","return_count","email_engagement_rate"]
def run(user):
 d=customers(user);X=d[FEATURES].apply(pd.to_numeric,errors="coerce").fillna(0);y=pd.to_numeric(d.synthetic_future_12m_value)
 if len(d)<20:return d,{}
 a,b,ya,yb=train_test_split(X,y,test_size=.2,random_state=42)
 m=HistGradientBoostingRegressor(max_iter=100,random_state=42).fit(a,ya)
 pred=np.maximum(m.predict(X),0);d["predicted_clv_12m"]=pred.round(2)
 q=d.predicted_clv_12m.quantile([.35,.75])
 d["clv_segment"]=d.predicted_clv_12m.apply(lambda x:"High Value" if x>=q.loc[.75] else ("Mid Value" if x>=q.loc[.35] else "Low Value"))
 p=np.maximum(m.predict(b),0)
 return d,{"mae":round(float(mean_absolute_error(yb,p)),2),"rmse":round(float(np.sqrt(mean_squared_error(yb,p))),2),"customers_scored":len(d)}
