import os,time
from backend.agents.retrieval_agent import retrieve
from backend.services.telemetry import log
def llm(prompt,user,purpose):
 t=time.time();key=os.getenv("OPENAI_API_KEY","");model=os.getenv("OPENAI_MODEL","gpt-4o-mini")
 if not key:
  log(user,"fallback",0,0,(time.time()-t)*1000,0,"fallback",purpose)
  return "LLM not configured. Use predicted CLV to prioritize relevant loyalty benefits and test win-back campaigns for at-risk customers. Validate uplift with a control group and respect consent."
 try:
  from openai import OpenAI
  r=OpenAI(api_key=key).chat.completions.create(model=model,temperature=.2,messages=[{"role":"system","content":"You are a responsible CRM analyst. Use only provided evidence, state uncertainty, respect consent, and recommend human-reviewed experiments."},{"role":"user","content":prompt}])
  i=int(r.usage.prompt_tokens or 0);o=int(r.usage.completion_tokens or 0);cost=i*.00000015+o*.00000060
  log(user,model,i,o,(time.time()-t)*1000,cost,"success",purpose);return r.choices[0].message.content or ""
 except Exception as e:
  log(user,model,0,0,(time.time()-t)*1000,0,"error",purpose);return f"LLM request failed: {e}"
def recommend(row,user):
 topic="high_value" if row.get("clv_segment")=="High Value" else ("churn_risk" if row.get("known_segment")=="At-Risk" else "loyalty")
 ev=retrieve(f"CLV {row.get('predicted_clv_12m')} frequency {row.get('purchase_frequency_monthly')} returns {row.get('return_count')}",topic)
 ans=llm(f"Explain this customer value estimate, recommend 3 retention actions, evidence, limitations and measurement plan. Customer: {row}; playbooks: {ev}",user,"clv_recommendation")
 return {"answer":ans,"evidence":ev}
def chat(q,user,summary):return llm(f"Answer using only authorized aggregates. Question: {q}; data: {summary}",user,"customer_chat")
