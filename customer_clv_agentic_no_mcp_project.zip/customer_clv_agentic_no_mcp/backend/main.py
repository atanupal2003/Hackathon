from fastapi import FastAPI,Header,HTTPException
from pydantic import BaseModel
from shared.security import authenticate,user_context
from backend.agents.clv_agent import run
from backend.agents.recommendation_agent import recommend,chat
from backend.services.telemetry import audit,usage,audits
app=FastAPI(title="Customer CLV AI API")
class Login(BaseModel):username:str;password:str
class Rec(BaseModel):customer_id:str
class Chat(BaseModel):question:str
def current(x_username:str=Header(default="")):
 u=user_context(x_username)
 if not u:raise HTTPException(401,"Missing or invalid demo identity")
 return u
def need(u,s):
 if s not in u["screens"]:raise HTTPException(403,f"Persona {u['persona']} cannot access {s}")
@app.get("/health")
def health():return {"status":"ok","service":"customer-clv-backend"}
@app.post("/auth/login")
def login(b:Login):
 u=authenticate(b.username,b.password)
 if not u:raise HTTPException(401,"Invalid username/password")
 audit(u,"login");return u
@app.get("/dashboard")
def dashboard(x_username:str=Header(default="")):
 u=current(x_username);need(u,"Executive Dashboard");d,m=run(u)
 return {"customer_count":len(d),"average_clv":round(float(d.predicted_clv_12m.mean()),2),"high_value":int((d.clv_segment=="High Value").sum()),"low_value":int((d.clv_segment=="Low Value").sum()),"segments":d.groupby("clv_segment").size().to_dict(),"metrics":m}
@app.get("/customers")
def get_customers(segment:str="",q:str="",x_username:str=Header(default="")):
 u=current(x_username);need(u,"Customer Explorer");d,_=run(u)
 if segment:d=d[d.clv_segment==segment]
 if q:d=d[d.customer_id.str.contains(q,case=False)|d.location.str.contains(q,case=False)]
 return d.sort_values("predicted_clv_12m",ascending=False).head(1000).to_dict("records")
@app.get("/predictions")
def predictions(x_username:str=Header(default="")):
 u=current(x_username);need(u,"CLV Predictions");d,m=run(u)
 return {"metrics":m,"records":d.sort_values("predicted_clv_12m",ascending=False).head(1000).to_dict("records")}
@app.post("/recommend")
def rec(b:Rec,x_username:str=Header(default="")):
 u=current(x_username);need(u,"Retention Recommendations");d,_=run(u);r=d[d.customer_id==b.customer_id]
 if r.empty:raise HTTPException(404,"Customer outside authorized scope or not found")
 row=r.iloc[0].to_dict();out=recommend(row,u);audit(u,"recommendation",b.customer_id);return {"customer":row,**out}
@app.post("/chat")
def chat_api(b:Chat,x_username:str=Header(default="")):
 u=current(x_username);need(u,"Customer AI Assistant")
 d,_=run(u);s=d.groupby("clv_segment").agg(customers=("customer_id","count"),average_clv=("predicted_clv_12m","mean")).reset_index().to_dict("records")
 ans=chat(b.question,u,s);audit(u,"chat",b.question[:150]);return {"answer":ans}
@app.get("/llm-usage")
def llm_usage(x_username:str=Header(default="")):
 u=current(x_username);need(u,"LLM Usage Dashboard");d=usage(u)
 return {"records":d.fillna("").to_dict("records"),"count":len(d),"input_tokens":int(d.input_tokens.sum()) if len(d) else 0,"output_tokens":int(d.output_tokens.sum()) if len(d) else 0,"cost":float(d.cost.sum()) if len(d) else 0}
@app.get("/audit")
def audit_api(x_username:str=Header(default="")):
 u=current(x_username);need(u,"Access & Audit");return audits(u).fillna("").to_dict("records")
