from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]; DATA=ROOT/"data"
def load(name):return pd.read_csv(DATA/name).fillna("")
def customers(user):return load("customers.csv").query("location in @user['locations']").copy()
def playbooks():return load("marketing_playbooks.csv").to_dict("records")
