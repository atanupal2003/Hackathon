# Inventory Sentinel AI — Modular Python Project (No MCP)

A modular hackathon MVP for inventory anomaly detection, investigation assistance, incident-playbook retrieval, persona-based screens, and LLM usage/audit dashboards. **This version removes MCP completely**: no MCP server, no MCP client, no MCP dependency, and no MCP endpoint. The retrieval agent calls ChromaDB directly.

## Architecture
- `frontend/app.py`: Streamlit UI (port 8501).
- `backend/main.py`: FastAPI REST API (port 8000), persona checks, data endpoints and agent invocation.
- `backend/agents/detection_agent.py`: delegates inventory anomaly detection to the data service.
- `backend/agents/investigation_agent.py`: optional OpenAI investigation/chat with fallback responses.
- `backend/agents/retrieval_agent.py`: ChromaDB incident-playbook retrieval with keyword fallback.
- `backend/services/data_service.py`: CSV loading, persona scope, Isolation Forest and rule-based anomaly flags.
- `backend/services/telemetry.py`: SQLite LLM usage and audit events.
- `shared/security.py`: demo personas, screen permissions, store/warehouse scope.
- `data/`: synthetic inventory, warehouse transactions and historical incidents.

## Requirements
Python 3.10–3.12 recommended.

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
$env:PYTHONPATH="."
```

## Start the backend (Terminal 1)
```powershell
$env:PYTHONPATH="."
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload
```

## Start the frontend (Terminal 2)
```powershell
$env:PYTHONPATH="."
streamlit run frontend/app.py --server.port 8501
```

Open the Streamlit URL shown in the terminal. API documentation: `http://127.0.0.1:8000/docs`. Only two processes are required; there is no MCP service or port 8001.

## Demo accounts
- Store Manager: `store.manager` / `StoreDemo!26` — Dashboard, Anomaly Explorer, Chat.
- Warehouse Supervisor: `warehouse.supervisor` / `WarehouseDemo!26` — Dashboard, Explorer, Investigation, Chat.
- Loss Prevention Analyst: `loss.analyst` / `LossDemo!26` — Dashboard, Explorer, Investigation, Chat, LLM Usage.
- Administrator: `admin` / `AdminDemo!26` — all screens, including Access & Audit.

## Optional LLM
Set these environment variables in the backend terminal before starting FastAPI:
```powershell
$env:OPENAI_API_KEY="your-key"
$env:OPENAI_MODEL="gpt-4o-mini"
```
Without an API key, investigation/chat returns fallback guidance and records a fallback event. Cost estimates in telemetry are illustrative and must be updated to actual provider pricing.

## ChromaDB
ChromaDB stores synthetic incident playbooks in `chroma_store/`. If vector retrieval fails, the retrieval agent falls back to keyword matching. First use may initialize an embedding model.

## Security and limitations
This is a local demo. Static credentials and the `X-Username` header are not production authentication. Use verified Entra ID/OIDC/JWT tokens, secure service-to-service authentication, secrets management and production database controls before deployment. Synthetic anomalies are not proof of theft; validate precision/recall against reviewed cases.
