import os,requests,pandas as pd,streamlit as st
API=os.getenv("INVENTORY_API_URL","http://127.0.0.1:8000")
SCREENS={
"Store Manager":["Executive Dashboard","Anomaly Explorer","Inventory AI Chat"],
"Warehouse Supervisor":["Executive Dashboard","Anomaly Explorer","Agentic Investigation","Inventory AI Chat"],
"Loss Prevention Analyst":["Executive Dashboard","Anomaly Explorer","Agentic Investigation","Inventory AI Chat","LLM Usage Dashboard"],
"Administrator":["Executive Dashboard","Anomaly Explorer","Agentic Investigation","Inventory AI Chat","LLM Usage Dashboard","Access & Audit"]}
st.set_page_config(page_title="Inventory Sentinel AI",page_icon="📦",layout="wide")
def call(method,path,username=None,**kw):
    headers=kw.pop("headers",{})
    if username: headers["X-Username"]=username
    try:
        r=requests.request(method,API+path,headers=headers,timeout=60,**kw)
        if not r.ok:
            try: detail=r.json().get("detail",r.text)
            except Exception: detail=r.text
            st.error(f"Backend {r.status_code}: {detail}"); return None
        return r.json()
    except requests.RequestException as e:
        st.error(f"Backend unavailable at {API}. Start backend service first. {e}"); return None
if "user" not in st.session_state: st.session_state.user=None
st.sidebar.title("📦 Inventory Sentinel AI")
if not st.session_state.user:
    st.title("Inventory Sentinel AI")
    with st.form("login"):
        u=st.text_input("Username","store.manager"); p=st.text_input("Password",type="password")
        go=st.form_submit_button("Sign in",type="primary")
    if go:
        data=call("POST","/auth/login",json={"username":u,"password":p})
        if data: st.session_state.user=data; st.rerun()
    with st.expander("Demo credentials"):
        st.markdown("Store Manager: `store.manager` / `StoreDemo!26`\n\nWarehouse Supervisor: `warehouse.supervisor` / `WarehouseDemo!26`\n\nLoss Prevention: `loss.analyst` / `LossDemo!26`\n\nAdministrator: `admin` / `AdminDemo!26`")
    st.warning("Demo authentication only; use enterprise SSO in production.")
    st.stop()
u=st.session_state.user; username=u["username"]; persona=u["persona"]
st.sidebar.success(persona); st.sidebar.caption(username)
screen=st.sidebar.radio("Screens allowed for this persona",SCREENS.get(persona,[]))
if st.sidebar.button("Sign out"): st.session_state.user=None; st.rerun()
st.title("📦 Inventory Sentinel AI"); st.caption(f"Persona-restricted workspace · {persona}")
if screen=="Executive Dashboard":
    d=call("GET","/dashboard",username)
    if d:
        cols=st.columns(4)
        for c,label,val in zip(cols,["Records","Flagged anomalies","Flag rate","Negative variance units"],[f"{d['total_records']:,}",f"{d['flagged_count']:,}",f"{d['flag_rate_pct']:.1f}%",f"{d['negative_variance_units']:,}"]): c.metric(label,val)
        a,b=st.columns(2)
        trend=pd.DataFrame(d["trend"])
        with a:
            st.subheader("Anomaly trend")
            if not trend.empty: st.line_chart(trend.set_index("day")[["total","anomalies"]])
        with b:
            st.subheader("Anomalies by category")
            x=pd.DataFrame(list(d["by_category"].items()),columns=["category","count"])
            if not x.empty: st.bar_chart(x.set_index("category"))
        x=pd.DataFrame(list(d["by_store"].items()),columns=["store","count"])
        st.subheader("Anomalies by store")
        if not x.empty: st.bar_chart(x.set_index("store"))
elif screen=="Anomaly Explorer":
    a,b=st.columns(2)
    cat=a.selectbox("Category",["","Electronics","Grocery","Home","Apparel","Personal Care"])
    store=b.selectbox("Store",[""]+[f"STORE-{i:03d}" for i in range(1,9)])
    score=st.slider("Minimum anomaly score",-0.2,.5,0.0,.01)
    rows=call("GET","/anomalies",username,params={"category":cat,"store_id":store,"min_score":score})
    if rows is not None:
        df=pd.DataFrame(rows); st.dataframe(df,use_container_width=True)
        if not df.empty: st.download_button("Download authorized results",df.to_csv(index=False),"anomalies.csv","text/csv")
elif screen=="Agentic Investigation":
    rows=call("GET","/anomalies",username,params={"min_score":-1})
    if rows:
        choice=st.selectbox("Choose anomaly",[f"{i} | {r['date']} | {r['store_id']} | {r['category']} | variance {r['variance_qty']}" for i,r in enumerate(rows)])
        if st.button("Run investigation",type="primary"):
            result=call("POST","/investigate",username,json={"record_index":int(choice.split(" | ",1)[0])})
            if result:
                st.subheader("Agent recommendation"); st.write(result["answer"])
                st.subheader("Authorized record"); st.json(result["record"])
                st.subheader("Retrieved playbooks"); st.dataframe(pd.DataFrame(result["evidence"]),use_container_width=True)
elif screen=="Inventory AI Chat":
    q=st.text_area("Ask about your authorized inventory")
    if st.button("Ask assistant",type="primary",disabled=not q.strip()):
        d=call("POST","/chat",username,json={"question":q})
        if d: st.write(d["answer"])
elif screen=="LLM Usage Dashboard":
    d=call("GET","/llm-usage",username)
    if d:
        a,b,c,e=st.columns(4); a.metric("Requests",d["count"]); b.metric("Input tokens",f"{d['input_tokens']:,}"); c.metric("Output tokens",f"{d['output_tokens']:,}"); e.metric("Estimated cost",f"${d['estimated_cost_usd']:.5f}")
        df=pd.DataFrame(d["records"])
        if not df.empty:
            if "ts" in df: df["day"]=pd.to_datetime(df.ts).dt.date
            if "day" in df: st.line_chart(df.groupby("day").estimated_cost_usd.sum())
            st.dataframe(df,use_container_width=True)
        else: st.info("No LLM calls recorded yet.")
elif screen=="Access & Audit":
    d=call("GET","/audit",username)
    if d is not None: st.dataframe(pd.DataFrame(d),use_container_width=True)
st.caption("An anomaly is an investigation lead, not proof of theft. LLM outputs require human review.")
