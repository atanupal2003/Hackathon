import os,requests,pandas as pd,streamlit as st
API=os.getenv("INFLUENCER_API_URL","http://127.0.0.1:8000")
SCREENS={"Campaign Manager":["Executive Dashboard","Product Explorer","Influencer Matching","Campaign Insights","AI Campaign Assistant","LLM Usage Dashboard"],"Brand Analyst":["Executive Dashboard","Product Explorer","Influencer Matching","Campaign Insights","AI Campaign Assistant"],"Regional Marketer":["Executive Dashboard","Product Explorer","Influencer Matching","Campaign Insights"],"Administrator":["Executive Dashboard","Product Explorer","Influencer Matching","Campaign Insights","AI Campaign Assistant","LLM Usage Dashboard","Access & Audit"]}
st.set_page_config(page_title="Influencer Match AI",page_icon="🎯",layout="wide")
def api(method,path,user=None,**kw):
 h=kw.pop("headers",{})
 if user:h["X-Username"]=user
 try:
  r=requests.request(method,API+path,headers=h,timeout=90,**kw)
  if not r.ok:st.error(f"Backend {r.status_code}: {r.text}");return None
  return r.json()
 except Exception as e:st.error(f"Backend unavailable: {e}");return None
if "user" not in st.session_state:st.session_state.user=None
st.sidebar.title("🎯 Influencer Match AI")
if not st.session_state.user:
 st.title("Influencer Matching & Campaign Intelligence")
 st.write("Match products to creators using audience fit, engagement, brand affinity, past ROI and budget.")
 with st.form("login"):
  name=st.text_input("Username","campaign.manager");pwd=st.text_input("Password",type="password");go=st.form_submit_button("Sign in")
 if go:
  u=api("POST","/auth/login",json={"username":name,"password":pwd})
  if u:st.session_state.user=u;st.rerun()
 with st.expander("Demo accounts"):
  st.write("Campaign Manager: campaign.manager / CampaignDemo!26")
  st.write("Brand Analyst: brand.analyst / BrandDemo!26")
  st.write("Regional Marketer: regional.marketer / RegionDemo!26")
  st.write("Administrator: admin / AdminDemo!26")
 st.stop()
u=st.session_state.user;name=u["username"];persona=u["persona"];st.sidebar.success(persona)
screen=st.sidebar.radio("Authorized screens",SCREENS[persona])
if st.sidebar.button("Sign out"):st.session_state.user=None;st.rerun()
st.title("🎯 Influencer Matching AI");st.caption(f"Persona-restricted workspace · {persona}")
if screen=="Executive Dashboard":
 d=api("GET","/dashboard",name)
 if d:
  a,b,c,e=st.columns(4);a.metric("Products",d["products"]);b.metric("Influencers",d["influencers"]);c.metric("Campaigns",d["campaigns"]);e.metric("Average historical ROI",f"{d['average_historical_roi']:.2f}x")
  st.metric("Average engagement",f"{d['avg_engagement_rate']:.2f}%")
elif screen=="Product Explorer":
 d=api("GET","/products",name)
 if d is not None:
  df=pd.DataFrame(d);st.dataframe(df,use_container_width=True)
  if len(df):st.download_button("Download products",df.to_csv(index=False),"products.csv","text/csv")
elif screen=="Influencer Matching":
 d=api("GET","/products",name)
 if d:
  df=pd.DataFrame(d);chosen=st.selectbox("Select product",df.apply(lambda x:f"{x.product_id} | {x.product_name} | Budget ${x.campaign_budget_usd}",axis=1));pid=chosen.split(" | ")[0]
  a,b=st.columns(2)
  with a:
   if st.button("Find best-fit influencers",type="primary"):
    r=api("POST","/match",name,json={"product_id":pid})
    if r:st.subheader("Ranked influencer matches");st.dataframe(pd.DataFrame(r["matches"]),use_container_width=True)
  with b:
   if st.button("Generate AI recommendation"):
    r=api("POST","/recommend",name,json={"product_id":pid})
    if r:
     st.subheader("Recommendation");st.write(r["answer"]);st.subheader("Top matches");st.dataframe(pd.DataFrame(r["matches"]),use_container_width=True);st.subheader("Retrieved playbooks");st.dataframe(pd.DataFrame(r["evidence"]),use_container_width=True)
elif screen=="Campaign Insights":
 d=api("GET","/campaign-insights",name)
 if d:
  a,b,c=st.columns(3);a.metric("Average ROI",f"{d['average_roi']:.2f}x");b.metric("Total spend",f"${d['total_spend']:,.0f}");c.metric("Revenue",f"${d['total_revenue']:,.0f}")
  df=pd.DataFrame(d["records"])
  if len(df):st.bar_chart(df.groupby("campaign_status").roi.mean());st.dataframe(df,use_container_width=True)
elif screen=="AI Campaign Assistant":
 q=st.text_area("Ask about creator matching, budget or ROI")
 if st.button("Ask assistant",disabled=not q.strip()):
  r=api("POST","/chat",name,json={"question":q})
  if r:st.write(r["answer"])
elif screen=="LLM Usage Dashboard":
 d=api("GET","/llm-usage",name)
 if d:
  a,b,c,e=st.columns(4);a.metric("Requests",d["count"]);b.metric("Input tokens",d["input_tokens"]);c.metric("Output tokens",d["output_tokens"]);e.metric("Estimated cost",f"${d['cost']:.5f}")
  df=pd.DataFrame(d["records"])
  if len(df):df["day"]=pd.to_datetime(df.ts).dt.date;st.line_chart(df.groupby("day").cost.sum());st.dataframe(df,use_container_width=True)
  else:st.info("No LLM calls yet.")
elif screen=="Access & Audit":
 d=api("GET","/audit",name)
 if d is not None:st.dataframe(pd.DataFrame(d),use_container_width=True)
st.caption("Synthetic-data MVP. Validate creator authenticity, disclosures, brand safety, usage rights and ROI attribution before contracting.")
