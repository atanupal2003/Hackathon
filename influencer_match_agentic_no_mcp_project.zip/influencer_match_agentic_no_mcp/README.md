# Influencer Matching Agentic AI — No MCP, No LangChain

Python 3.10–3.12 recommended. Separate Streamlit frontend, FastAPI backend, native Python matching/recommendation/retrieval agents, ChromaDB RAG, optional OpenAI, SQLite telemetry/audit. No MCP and no LangChain.

Install:
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```
Terminal 1:
```powershell
.venv\Scripts\Activate.ps1
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload
```
Terminal 2:
```powershell
.venv\Scripts\Activate.ps1
streamlit run frontend/app.py --server.port 8501
```
No MCP server required. API docs: http://127.0.0.1:8000/docs.

Demo accounts:
- Campaign Manager: `campaign.manager` / `CampaignDemo!26`
- Brand Analyst: `brand.analyst` / `BrandDemo!26`
- Regional Marketer: `regional.marketer` / `RegionDemo!26`
- Administrator: `admin` / `AdminDemo!26`

Synthetic data: 180 influencers, 40 products, 450 historical campaign rows, 5 playbooks. Regional Marketer is scoped to India and Singapore. Static credentials and username headers are demo-only; use verified Entra ID/OIDC in production.

Matching weights: interests 25%, location 20%, age fit 15%, engagement 15%, brand affinity 10%, historical ROI 10%, micro-influencer preference 5%. Within-budget creators rank first. Tune with actual campaign outcomes before production.

Optional OpenAI: set `OPENAI_API_KEY` and optionally `OPENAI_MODEL` in backend terminal. Without a key, fallback guidance is returned and logged. Cost rates are illustrative. ChromaDB embedding initialization can download a model; a keyword fallback is included.

Human-review all creator selections. Validate audience authenticity, disclosure, brand safety, usage rights, contracts and attribution before spending.
