PERSONAS={
"Campaign Manager":{"username":"campaign.manager","password":"CampaignDemo!26","screens":["Executive Dashboard","Product Explorer","Influencer Matching","Campaign Insights","AI Campaign Assistant","LLM Usage Dashboard"],"regions":["India","United States","United Kingdom","Canada","Australia","Singapore"]},
"Brand Analyst":{"username":"brand.analyst","password":"BrandDemo!26","screens":["Executive Dashboard","Product Explorer","Influencer Matching","Campaign Insights","AI Campaign Assistant"],"regions":["India","United States","United Kingdom","Canada","Australia","Singapore"]},
"Regional Marketer":{"username":"regional.marketer","password":"RegionDemo!26","screens":["Executive Dashboard","Product Explorer","Influencer Matching","Campaign Insights"],"regions":["India","Singapore"]},
"Administrator":{"username":"admin","password":"AdminDemo!26","screens":["Executive Dashboard","Product Explorer","Influencer Matching","Campaign Insights","AI Campaign Assistant","LLM Usage Dashboard","Access & Audit"],"regions":["India","United States","United Kingdom","Canada","Australia","Singapore"]}}
def authenticate(username,password):
 for p,r in PERSONAS.items():
  if r["username"]==username and r["password"]==password:return {"username":username,"persona":p,"screens":r["screens"],"regions":r["regions"]}
 return None
def user_context(username):
 for p,r in PERSONAS.items():
  if r["username"]==username:return {"username":username,"persona":p,"screens":r["screens"],"regions":r["regions"]}
 return None
