import os,time
from backend.agents.retrieval_agent import retrieve
from backend.services.telemetry import log
def llm(prompt,user,purpose):
 t=time.time();key=os.getenv("OPENAI_API_KEY","");model=os.getenv("OPENAI_MODEL","gpt-4o-mini")
 if not key:
  log(user,"fallback",0,0,(time.time()-t)*1000,0,"fallback",purpose)
  return "LLM is not configured. Treat match scores as a shortlist, then validate audience authenticity, brand safety, disclosure, usage rights, budget and attribution before contracting."
 try:
  from openai import OpenAI
  r=OpenAI(api_key=key).chat.completions.create(model=model,temperature=.2,messages=[{"role":"system","content":"You are a careful influencer marketing analyst. Use only supplied metrics, state uncertainty, never guarantee ROI, and require human review."},{"role":"user","content":prompt}])
  i=int(r.usage.prompt_tokens or 0);o=int(r.usage.completion_tokens or 0);cost=i*.00000015+o*.00000060
  log(user,model,i,o,(time.time()-t)*1000,cost,"success",purpose);return r.choices[0].message.content or ""
 except Exception as e:
  log(user,model,0,0,(time.time()-t)*1000,0,"error",purpose);return f"LLM request failed: {e}"
def recommend(product,matches,user):
 ev=retrieve(f"influencer match {product['product_name']} {product['category']} budget {product['campaign_budget_usd']}","matching")
 return {"answer":llm(f"Explain top creator matches, tradeoffs, checks and campaign test plan. Product: {product}; matches: {matches}; playbooks: {ev}",user,"influencer_recommendation"),"evidence":ev}
def chat(question,user,summary):return llm(f"Answer using only these authorized campaign aggregates. Question: {question}; data: {summary}",user,"campaign_chat")
