from pathlib import Path
from backend.services.data_service import playbooks
ROOT=Path(__file__).resolve().parents[2]
def retrieve(query,topic="",k=3):
 docs=playbooks()
 try:
  import chromadb
  client=chromadb.PersistentClient(path=str(ROOT/"chroma_store"));col=client.get_or_create_collection("influencer_campaign_playbooks")
  if col.count()==0:col.add(ids=[d["doc_id"] for d in docs],documents=[d["title"]+" "+d["topic"]+" "+d["text"] for d in docs],metadatas=[{"topic":d["topic"]} for d in docs])
  args={"query_texts":[query],"n_results":min(k,col.count())}
  if topic:args["where"]={"topic":topic}
  ids=col.query(**args)["ids"][0];return [d for d in docs if d["doc_id"] in ids]
 except Exception:
  terms=[w for w in query.lower().split() if len(w)>3];return sorted(docs,key=lambda d:sum(w in (d["title"]+" "+d["text"]).lower() for w in terms),reverse=True)[:k]
