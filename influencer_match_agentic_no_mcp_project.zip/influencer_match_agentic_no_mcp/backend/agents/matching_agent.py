from backend.services.data_service import products,influencers
def run(user,product_id):
 p=products(user);p=p[p.product_id==product_id]
 if p.empty:return None,[]
 prod=p.iloc[0];df=influencers(user).copy()
 def score(r):
  inter=set(str(r.interests).split("|")) & set(str(prod.target_interests).split("|"))
  interest=len(inter)/max(len(str(prod.target_interests).split("|")),1)
  loc=1 if r.primary_location in str(prod.target_locations).split("|") else .25
  age=1 if float(prod.target_age_min)<=float(r.audience_age_avg)<=float(prod.target_age_max) else .25
  eng=min(float(r.engagement_rate)/max(float(prod.minimum_engagement_rate),.005),1.5)/1.5
  brand={"High":1,"Medium":.7,"Low":.4}.get(r.brand_affinity,.5)
  roi=min(max(float(r.past_campaign_roi)/5,0),1)
  micro=1 if prod.preferred_creator_type!="Micro" or int(r.is_micro_influencer) else .45
  return round(100*(.25*interest+.20*loc+.15*age+.15*eng+.10*brand+.10*roi+.05*micro),2)
 df["match_score"]=df.apply(score,axis=1);df["estimated_cost_usd"]=df.estimated_rate_usd
 df["within_budget"]=df.estimated_cost_usd<=float(prod.campaign_budget_usd)
 df=df.sort_values(["within_budget","match_score"],ascending=[False,False]).head(30)
 return prod.to_dict(),df
