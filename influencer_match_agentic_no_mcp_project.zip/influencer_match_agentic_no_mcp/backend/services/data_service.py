from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]; DATA=ROOT/"data"
def load(name):return pd.read_csv(DATA/name).fillna("")
def products(user):
 d=load("products.csv");return d[d.target_locations.apply(lambda s:any(x in user["regions"] for x in str(s).split("|")))].copy()
def influencers(user):return load("influencers.csv").query("primary_location in @user['regions']").copy()
def campaigns(user):
 allowed=set(influencers(user).influencer_id);return load("campaign_history.csv").query("influencer_id in @allowed").copy()
def playbooks():return load("influencer_playbooks.csv").to_dict("records")
