from pathlib import Path
from datetime import datetime
import sqlite3,pandas as pd
DB=Path(__file__).resolve().parents[2]/"app_logs.db"
def conn():
 c=sqlite3.connect(DB,check_same_thread=False)
 c.execute("CREATE TABLE IF NOT EXISTS llm_usage(id INTEGER PRIMARY KEY,ts TEXT,username TEXT,persona TEXT,model TEXT,input_tokens INTEGER,output_tokens INTEGER,latency_ms REAL,cost REAL,status TEXT,purpose TEXT)")
 c.execute("CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,ts TEXT,username TEXT,persona TEXT,action TEXT,details TEXT)");c.commit();return c
def log(user,model,ins,outs,latency,cost,status,purpose):
 c=conn();c.execute("INSERT INTO llm_usage(ts,username,persona,model,input_tokens,output_tokens,latency_ms,cost,status,purpose) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(datetime.now().isoformat(),user["username"],user["persona"],model,ins,outs,latency,cost,status,purpose));c.commit();c.close()
def audit(user,action,details=""):
 c=conn();c.execute("INSERT INTO audit(ts,username,persona,action,details) VALUES(?,?,?,?,?)",(datetime.now().isoformat(),user["username"],user["persona"],action,str(details)[:300]));c.commit();c.close()
def usage(user):
 c=conn();d=pd.read_sql_query("SELECT * FROM llm_usage ORDER BY ts DESC",c);c.close()
 return d if user["persona"]=="Administrator" else d[d.username==user["username"]]
def audits(user):
 c=conn();d=pd.read_sql_query("SELECT * FROM audit ORDER BY ts DESC LIMIT 1000",c);c.close()
 return d if user["persona"]=="Administrator" else d[d.username==user["username"]]
