from fastapi import FastAPI,Header,HTTPException
from pydantic import BaseModel
from shared.security import authenticate,user_context
from backend.services.data_service import products,influencers,campaigns
from backend.agents.matching_agent import run
from backend.agents.recommendation_agent import recommend,chat
from backend.services.telemetry import audit,usage,audits
app=FastAPI(title="Influencer Matching AI API")
class Login(BaseModel):username:str;password:str
class MatchRequest(BaseModel):product_id:str
class ChatRequest(BaseModel):question:str
def current(x_username:str=Header(default="")):
 u=user_context(x_username)
 if not u:raise HTTPException(401,"Missing or invalid demo identity")
 return u
def need(u,s):
 if s not in u["screens"]:raise HTTPException(403,f"Persona {u['persona']} cannot access {s}")
@app.get("/health")
def health():return {"status":"ok","service":"influencer-matching-backend"}
@app.post("/auth/login")
def login(b:Login):
 u=authenticate(b.username,b.password)
 if not u:raise HTTPException(401,"Invalid username/password")
 audit(u,"login");return u
@app.get("/dashboard")
def dashboard(x_username:str=Header(default="")):
 u=current(x_username);need(u,"Executive Dashboard");p=products(u);c=campaigns(u);i=influencers(u)
 return {"products":len(p),"influencers":len(i),"campaigns":len(c),"average_historical_roi":round(float(c.roi.mean()),2) if len(c) else 0,"avg_engagement_rate":round(float(i.engagement_rate.mean())*100,2) if len(i) else 0}
@app.get("/products")
def product_list(x_username:str=Header(default="")):
 u=current(x_username);need(u,"Product Explorer");return products(u).to_dict("records")
@app.get("/campaign-insights")
def insights(x_username:str=Header(default="")):
 u=current(x_username);need(u,"Campaign Insights");c=campaigns(u)
 return {"records":c.to_dict("records"),"average_roi":round(float(c.roi.mean()),2) if len(c) else 0,"total_spend":round(float(c.spend_usd.sum()),2) if len(c) else 0,"total_revenue":round(float(c.revenue_usd.sum()),2) if len(c) else 0}
@app.post("/match")
def match(b:MatchRequest,x_username:str=Header(default="")):
 u=current(x_username);need(u,"Influencer Matching");p,df=run(u,b.product_id)
 if p is None:raise HTTPException(404,"Product not found in authorized scope")
 audit(u,"influencer_match",b.product_id);return {"product":p,"matches":df.to_dict("records")}
@app.post("/recommend")
def recommendation(b:MatchRequest,x_username:str=Header(default="")):
 u=current(x_username);need(u,"Influencer Matching");p,df=run(u,b.product_id)
 if p is None:raise HTTPException(404,"Product not found in authorized scope")
 matches=df.head(10).to_dict("records");out=recommend(p,matches,u);audit(u,"recommendation",b.product_id);return {"product":p,"matches":matches,**out}
@app.post("/chat")
def chat_api(b:ChatRequest,x_username:str=Header(default="")):
 u=current(x_username);need(u,"AI Campaign Assistant");c=campaigns(u)
 summary={"campaign_count":len(c),"average_roi":round(float(c.roi.mean()),2) if len(c) else 0,"total_spend":round(float(c.spend_usd.sum()),2) if len(c) else 0}
 return {"answer":chat(b.question,u,summary)}
@app.get("/llm-usage")
def llm_usage(x_username:str=Header(default="")):
 u=current(x_username);need(u,"LLM Usage Dashboard");d=usage(u)
 return {"records":d.fillna("").to_dict("records"),"count":len(d),"input_tokens":int(d.input_tokens.sum()) if len(d) else 0,"output_tokens":int(d.output_tokens.sum()) if len(d) else 0,"cost":float(d.cost.sum()) if len(d) else 0}
@app.get("/audit")
def audit_api(x_username:str=Header(default="")):
 u=current(x_username);need(u,"Access & Audit");return audits(u).fillna("").to_dict("records")
