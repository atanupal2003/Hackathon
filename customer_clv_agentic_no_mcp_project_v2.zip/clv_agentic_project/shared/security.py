PERSONAS = {
 "CRM Manager":{"username":"crm.manager","password":"CRMdemo!26","screens":["Executive Dashboard","Customer Explorer","CLV & Churn","Retention Recommendations","Customer AI Assistant","LLM Usage Dashboard"],"regions":["India","United Kingdom","United States","Singapore"],"read_only":False},
 "Retention Analyst":{"username":"retention.analyst","password":"RetentionDemo!26","screens":["Executive Dashboard","Customer Explorer","CLV & Churn","Retention Recommendations","Customer AI Assistant"],"regions":["India","United Kingdom"],"read_only":False},
 "Regional Marketing Manager":{"username":"regional.manager","password":"RegionDemo!26","screens":["Executive Dashboard","Customer Explorer","CLV & Churn","Retention Recommendations"],"regions":["India"],"read_only":False},
 "Administrator":{"username":"admin","password":"AdminDemo!26","screens":["Executive Dashboard","Customer Explorer","CLV & Churn","Retention Recommendations","Customer AI Assistant","LLM Usage Dashboard","Access & Audit"],"regions":["India","United Kingdom","United States","Singapore"],"read_only":False},
 "Auditor":{"username":"auditor","password":"AuditDemo!26","screens":["Executive Dashboard","Customer Explorer","CLV & Churn","LLM Usage Dashboard","Access & Audit"],"regions":["India","United Kingdom","United States","Singapore"],"read_only":True}
}
def _user(username, persona, cfg):
 return {"username":username,"persona":persona,"screens":cfg["screens"],"regions":cfg["regions"],"read_only":cfg["read_only"]}
def authenticate(username,password):
 for persona,cfg in PERSONAS.items():
  if cfg["username"]==username and cfg["password"]==password: return _user(username,persona,cfg)
 return None
def user_context(username):
 for persona,cfg in PERSONAS.items():
  if cfg["username"]==username: return _user(username,persona,cfg)
 return None
