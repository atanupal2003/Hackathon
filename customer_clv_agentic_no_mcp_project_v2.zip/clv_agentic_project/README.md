# Customer Lifetime Value Agentic AI — No MCP / No LangChain

Modular prototype: Streamlit frontend, FastAPI backend, Random Forest CLV and churn agents, ChromaDB retention-playbook retrieval, optional OpenAI, synthetic CSV datasets, persona restrictions, SQLite usage and audit logging.

## Install (Python 3.10–3.12 recommended)
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
$env:PYTHONPATH="."
```
Backend Terminal 1:
```powershell
$env:PYTHONPATH="."
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload
```
Frontend Terminal 2:
```powershell
streamlit run frontend/app.py --server.port 8501
```
API docs: http://127.0.0.1:8000/docs

## Demo accounts
- CRM Manager: `crm.manager` / `CRMdemo!26`
- Retention Analyst: `retention.analyst` / `RetentionDemo!26`
- Regional Marketing Manager: `regional.manager` / `RegionDemo!26`
- Administrator: `admin` / `AdminDemo!26`
- Auditor: `auditor` / `AuditDemo!26`

## Optional OpenAI
Set `OPENAI_API_KEY` and optionally `OPENAI_MODEL` in the backend terminal before starting FastAPI. Without a key, fallback guidance is used and fallback events are logged.

## Synthetic datasets
- `customers.csv`: 1,200 synthetic customer records with purchase and engagement features, future-value labels and 90-day churn labels.
- `transactions.csv`: synthetic transaction history.
- `retention_playbooks.csv`: 10 synthetic retention guidance documents indexed in ChromaDB.

## Modeling notes
RandomForestRegressor predicts synthetic future 12-month value; RandomForestClassifier estimates synthetic 90-day churn risk. Holdout MAE and ROC-AUC are illustrative only and should not be treated as real-world model validation. CLV is estimated, not guaranteed.

## Security
Static demo credentials and `X-Username` headers are not production authentication. Use verified Entra ID/OIDC tokens and server-side authorization in production. Respect consent, contact frequency, opt-outs and privacy requirements. LLM cost rates in code are illustrative.
