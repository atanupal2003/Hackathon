import os,requests,pandas as pd,streamlit as st
API=os.getenv("CLV_API_URL","http://127.0.0.1:8000")
SCREENS={
"CRM Manager":["Executive Dashboard","Customer Explorer","CLV & Churn","Retention Recommendations","Customer AI Assistant","LLM Usage Dashboard"],
"Retention Analyst":["Executive Dashboard","Customer Explorer","CLV & Churn","Retention Recommendations","Customer AI Assistant"],
"Regional Marketing Manager":["Executive Dashboard","Customer Explorer","CLV & Churn","Retention Recommendations"],
"Administrator":["Executive Dashboard","Customer Explorer","CLV & Churn","Retention Recommendations","Customer AI Assistant","LLM Usage Dashboard","Access & Audit"],
"Auditor":["Executive Dashboard","Customer Explorer","CLV & Churn","LLM Usage Dashboard","Access & Audit"]}
st.set_page_config(page_title="Customer CLV Agentic AI",page_icon="💎",layout="wide")
def api(method,path,username=None,**kwargs):
 headers=kwargs.pop("headers",{})
 if username:headers["X-Username"]=username
 try:
  r=requests.request(method,API+path,headers=headers,timeout=120,**kwargs)
  if not r.ok:st.error(f"Backend {r.status_code}: {r.text}");return None
  return r.json()
 except Exception as e:st.error(f"Backend unavailable: {e}");return None
if "user" not in st.session_state:st.session_state.user=None
st.sidebar.title("💎 Customer CLV AI")
if not st.session_state.user:
 st.title("Customer Lifetime Value Agentic AI")
 st.write("Predict 12-month customer value, identify churn risk and generate evidence-based retention actions.")
 with st.form("login"):
  username=st.text_input("Username","crm.manager");password=st.text_input("Password",type="password");submit=st.form_submit_button("Sign in")
 if submit:
  u=api("POST","/auth/login",json={"username":username,"password":password})
  if u:st.session_state.user=u;st.rerun()
 with st.expander("Demo accounts"):
  st.write("CRM Manager: crm.manager / CRMdemo!26")
  st.write("Retention Analyst: retention.analyst / RetentionDemo!26")
  st.write("Regional Marketing Manager: regional.manager / RegionDemo!26")
  st.write("Administrator: admin / AdminDemo!26")
  st.write("Auditor: auditor / AuditDemo!26")
 st.stop()
user=st.session_state.user;username=user["username"];persona=user["persona"]
st.sidebar.success(persona);screen=st.sidebar.radio("Authorized screens",SCREENS.get(persona,["Executive Dashboard"]))
if st.sidebar.button("Sign out"):st.session_state.user=None;st.rerun()
st.title("💎 Customer Lifetime Value Agentic AI");st.caption(f"Persona-restricted workspace · {persona} · Synthetic data")
if screen=="Executive Dashboard":
 d=api("GET","/dashboard",username)
 if d:
  c=st.columns(4);c[0].metric("Customers",d["customers"]);c[1].metric("Predicted 12m CLV",f"${d['predicted_clv_total']:,.0f}");c[2].metric("High churn risk",d["high_churn_customers"]);c[3].metric("High-value customers",d["high_value_customers"])
  st.metric("Average predicted CLV",f"${d['average_clv']:,.2f}");st.caption(f"Holdout MAE: {d['model_metrics'].get('mae')} · Churn ROC-AUC: {d['model_metrics'].get('churn_auc')}")
elif screen=="Customer Explorer":
 d=api("GET","/customers",username)
 if d:
  df=pd.DataFrame(d);st.dataframe(df,use_container_width=True);st.download_button("Download predictions CSV",df.to_csv(index=False),"customer_clv_predictions.csv","text/csv")
elif screen=="CLV & Churn":
 d=api("GET","/clv",username)
 if d:
  df=pd.DataFrame(d["records"]);a,b=st.columns(2)
  with a:st.subheader("Average CLV by value band");st.bar_chart(df.groupby("value_band").predicted_12m_clv.mean())
  with b:st.subheader("Customers by churn risk");st.bar_chart(df.groupby("risk_band").size())
  st.subheader("Highest churn-risk customers");st.dataframe(df.sort_values("churn_risk_pct",ascending=False).head(50),use_container_width=True)
elif screen=="Retention Recommendations":
 d=api("GET","/customers",username)
 if d:
  df=pd.DataFrame(d);choice=st.selectbox("Choose customer",df.apply(lambda r:f"{r.customer_id} | CLV ${r.predicted_12m_clv:,.0f} | churn {r.churn_risk_pct:.0f}%",axis=1))
  if st.button("Generate retention plan",type="primary"):
   result=api("POST","/recommend",username,json={"customer_id":choice.split(" | ")[0]})
   if result:
    st.subheader("Retention recommendation");st.write(result["answer"]);st.subheader("Customer evidence");st.json(result["customer"]);st.subheader("Retrieved playbooks");st.dataframe(pd.DataFrame(result["evidence"]),use_container_width=True)
elif screen=="Customer AI Assistant":
 question=st.text_area("Ask about CLV, churn, segments or retention strategy")
 if st.button("Ask assistant",disabled=not question.strip()):
  result=api("POST","/chat",username,json={"question":question})
  if result:st.write(result["answer"]);st.dataframe(pd.DataFrame(result["evidence"]),use_container_width=True)
elif screen=="LLM Usage Dashboard":
 d=api("GET","/llm-usage",username)
 if d:
  c=st.columns(4);c[0].metric("Requests",d["count"]);c[1].metric("Input tokens",d["input_tokens"]);c[2].metric("Output tokens",d["output_tokens"]);c[3].metric("Estimated cost",f"${d['estimated_cost']:.5f}")
  df=pd.DataFrame(d["records"])
  if len(df):df["day"]=pd.to_datetime(df.ts).dt.date;st.line_chart(df.groupby("day").cost.sum());st.dataframe(df,use_container_width=True)
  else:st.info("No LLM calls recorded yet.")
elif screen=="Access & Audit":
 d=api("GET","/audit",username)
 if d is not None:st.dataframe(pd.DataFrame(d),use_container_width=True)
st.caption("Synthetic-data prototype. Respect consent, communication preferences, privacy law and human review.")
