from sklearn.ensemble import RandomForestRegressor,RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error,roc_auc_score
from backend.services.data_service import customers
FEATURES=["tenure_months","purchase_frequency_12m","avg_order_value","recency_days","loyalty_points","returns_12m","email_engagement_rate"]
def build_predictions(user):
 df=customers(user).copy()
 if df.empty:return df,{"mae":None,"churn_auc":None}
 X=df[FEATURES].apply(pd.to_numeric,errors="coerce").fillna(0)
 y=pd.to_numeric(df.realized_future_12m_value,errors="coerce").fillna(0)
 yc=pd.to_numeric(df.churned_next_90d,errors="coerce").fillna(0).astype(int)
 mae=auc=None
 if len(df)>=30:
  Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42)
  reg=RandomForestRegressor(n_estimators=100,min_samples_leaf=3,random_state=42,n_jobs=-1).fit(Xtr,ytr)
  mae=float(mean_absolute_error(yte,reg.predict(Xte)))
  Xtrc,Xtec,ytrc,ytec=train_test_split(X,yc,test_size=.2,random_state=42,stratify=yc if yc.nunique()>1 else None)
  clf=RandomForestClassifier(n_estimators=100,min_samples_leaf=3,random_state=42,class_weight="balanced",n_jobs=-1).fit(Xtrc,ytrc)
  try: auc=float(roc_auc_score(ytec,clf.predict_proba(Xtec)[:,1])) if ytec.nunique()>1 else None
  except Exception: auc=None
 reg=RandomForestRegressor(n_estimators=100,min_samples_leaf=3,random_state=42,n_jobs=-1).fit(X,y)
 clf=RandomForestClassifier(n_estimators=100,min_samples_leaf=3,random_state=42,class_weight="balanced",n_jobs=-1).fit(X,yc)
 df["predicted_12m_clv"]=reg.predict(X).clip(0)
 df["churn_risk_pct"]=clf.predict_proba(X)[:,1]*100
 df["risk_band"]=pd.cut(df.churn_risk_pct,[-.1,30,60,100],labels=["Low","Medium","High"]).astype(str)
 df["value_band"]=pd.qcut(df.predicted_12m_clv.rank(method="first"),4,labels=["Value 1","Value 2","Value 3","Value 4"])
 return df,{"mae":round(mae,2) if mae is not None else None,"churn_auc":round(auc,3) if auc is not None else None}
import pandas as pd
