import os,time
from backend.agents.retrieval_agent import retrieve
from backend.services.telemetry import log_llm
def call_llm(prompt,user,purpose):
 started=time.time();key=os.getenv("OPENAI_API_KEY","");model=os.getenv("OPENAI_MODEL","gpt-4o-mini")
 if not key:
  log_llm(user,"fallback",0,0,(time.time()-started)*1000,0,"fallback",purpose)
  return "LLM is not configured. Prioritize service recovery for recent issues, test relevant loyalty benefits or respectful win-back messages, honor consent and opt-outs, and measure incremental margin against a holdout group."
 try:
  from openai import OpenAI
  r=OpenAI(api_key=key).chat.completions.create(model=model,temperature=.2,messages=[
   {"role":"system","content":"You are a responsible CRM retention analyst. Use only supplied evidence, state uncertainty, avoid sensitive-attribute targeting, respect consent and opt-outs, and never guarantee future CLV."},
   {"role":"user","content":prompt}])
  ins=int(r.usage.prompt_tokens or 0);outs=int(r.usage.completion_tokens or 0);cost=ins*.00000015+outs*.00000060
  log_llm(user,model,ins,outs,(time.time()-started)*1000,cost,"success",purpose)
  return r.choices[0].message.content or ""
 except Exception as e:
  log_llm(user,model,0,0,(time.time()-started)*1000,0,"error",purpose);return f"LLM request failed: {e}"
def recommend(customer,user):
 docs=retrieve("retention action churn risk customer lifetime value loyalty win-back","retention")
 return {"answer":call_llm(f"Recommend a respectful retention plan, value rationale, channel, experiment and KPIs. Customer evidence: {customer}. Playbooks: {docs}",user,"retention_recommendation"),"evidence":docs}
def chat(question,user,summary):
 docs=retrieve(question)
 return {"answer":call_llm(f"Answer using only this scoped CLV summary and playbooks. Question: {question}; summary: {summary}; evidence: {docs}",user,"clv_chat"),"evidence":docs}
