from pathlib import Path
from backend.services.data_service import playbooks
ROOT=Path(__file__).resolve().parents[2]
def retrieve(query,topic="",k=3):
 docs=playbooks()
 try:
  import chromadb
  client=chromadb.PersistentClient(path=str(ROOT/"chroma_store"))
  col=client.get_or_create_collection("clv_retention_playbooks")
  if col.count()==0:
   col.add(ids=[d["playbook_id"] for d in docs],documents=[d["title"]+" "+d["topic"]+" "+d["text"] for d in docs],metadatas=[{"topic":d["topic"]} for d in docs])
  args={"query_texts":[query],"n_results":min(k,col.count())}
  if topic:args["where"]={"topic":topic}
  ids=col.query(**args)["ids"][0];by={d["playbook_id"]:d for d in docs}
  return [by[i] for i in ids if i in by]
 except Exception:
  terms=[t.lower() for t in query.split() if len(t)>3]
  return sorted(docs,key=lambda d:sum(t in (d["title"]+" "+d["text"]).lower() for t in terms),reverse=True)[:k]
