from fastapi import FastAPI,Header,HTTPException
from pydantic import BaseModel
from shared.security import authenticate,user_context
from backend.agents.clv_agent import build_predictions
from backend.agents.retention_agent import recommend,chat
from backend.services.telemetry import audit,usage,audits
app=FastAPI(title="Customer CLV Agentic AI API",version="1.0.0")
class LoginBody(BaseModel): username:str;password:str
class CustomerBody(BaseModel): customer_id:str
class ChatBody(BaseModel): question:str
def current(x_username:str=Header(default="")):
 u=user_context(x_username)
 if not u:raise HTTPException(401,"Missing or invalid demo identity")
 return u
def require_screen(user,screen):
 if screen not in user["screens"]:raise HTTPException(403,f"Persona {user['persona']} cannot access {screen}")
def preds(user):return build_predictions(user)
@app.get("/health")
def health():return {"status":"ok","service":"customer-clv-api","mcp":False,"langchain":False}
@app.post("/auth/login")
def login(body:LoginBody):
 u=authenticate(body.username,body.password)
 if not u:raise HTTPException(401,"Invalid username or password")
 audit(u,"login");return u
@app.get("/dashboard")
def dashboard(x_username:str=Header(default="")):
 u=current(x_username);require_screen(u,"Executive Dashboard");df,m=preds(u)
 return {"customers":len(df),"predicted_clv_total":round(float(df.predicted_12m_clv.sum()),2) if len(df) else 0,"high_churn_customers":int((df.churn_risk_pct>=60).sum()) if len(df) else 0,"average_clv":round(float(df.predicted_12m_clv.mean()),2) if len(df) else 0,"high_value_customers":int((df.value_band=="Value 4").sum()) if len(df) else 0,"model_metrics":m}
@app.get("/customers")
def customer_list(x_username:str=Header(default="")):
 u=current(x_username);require_screen(u,"Customer Explorer");df,_=preds(u)
 cols=["customer_id","region","customer_segment","tenure_months","purchase_frequency_12m","avg_order_value","recency_days","predicted_12m_clv","churn_risk_pct","risk_band","value_band"]
 return df[cols].to_dict("records")
@app.get("/clv")
def clv(x_username:str=Header(default="")):
 u=current(x_username);require_screen(u,"CLV & Churn");df,m=preds(u);return {"records":df.to_dict("records"),"metrics":m}
@app.post("/recommend")
def retention_recommend(body:CustomerBody,x_username:str=Header(default="")):
 u=current(x_username);require_screen(u,"Retention Recommendations")
 if u["read_only"]:raise HTTPException(403,"Auditor persona is read-only")
 df,_=preds(u);row=df[df.customer_id==body.customer_id]
 if row.empty:raise HTTPException(404,"Customer not found in authorized region")
 result=recommend(row.iloc[0].to_dict(),u);audit(u,"retention_recommendation",body.customer_id)
 return {"customer":row.iloc[0].to_dict(),**result}
@app.post("/chat")
def clv_chat(body:ChatBody,x_username:str=Header(default="")):
 u=current(x_username);require_screen(u,"Customer AI Assistant")
 if u["read_only"]:raise HTTPException(403,"Auditor persona is read-only")
 df,_=preds(u);summary={"customer_count":len(df),"predicted_clv_total":round(float(df.predicted_12m_clv.sum()),2) if len(df) else 0,"average_clv":round(float(df.predicted_12m_clv.mean()),2) if len(df) else 0,"high_churn_customers":int((df.churn_risk_pct>=60).sum()) if len(df) else 0}
 result=chat(body.question,u,summary);audit(u,"clv_chat",body.question[:100]);return result
@app.get("/llm-usage")
def llm_usage(x_username:str=Header(default="")):
 u=current(x_username);require_screen(u,"LLM Usage Dashboard");d=usage(u)
 return {"records":d.fillna("").to_dict("records"),"count":len(d),"input_tokens":int(d.input_tokens.sum()) if len(d) else 0,"output_tokens":int(d.output_tokens.sum()) if len(d) else 0,"estimated_cost":float(d.cost.sum()) if len(d) else 0}
@app.get("/audit")
def audit_api(x_username:str=Header(default="")):
 u=current(x_username);require_screen(u,"Access & Audit");return audits(u).fillna("").to_dict("records")
