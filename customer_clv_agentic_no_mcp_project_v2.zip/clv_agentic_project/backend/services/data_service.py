from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]; DATA=ROOT/"data"
def load(name): return pd.read_csv(DATA/name).fillna("")
def customers(user):
 df=load("customers.csv")
 return df[df.region.isin(user["regions"])].copy()
def transactions(user):
 ids=set(customers(user).customer_id)
 return load("transactions.csv").query("customer_id in @ids").copy()
def playbooks(): return load("retention_playbooks.csv").to_dict("records")
