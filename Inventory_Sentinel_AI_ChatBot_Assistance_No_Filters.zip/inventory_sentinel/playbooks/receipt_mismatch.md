# Receipt mismatch
1. Match dispatch and receipt references and confirm transit time.
2. Inspect goods-received records and proof of delivery.
3. Recount affected cartons and check unit conversions.
4. Check partial receipts and duplicate deliveries before raising a supplier/DC claim.
5. Attach the reconciliation evidence and obtain approval for any stock adjustment.
