# Stock variance and unusual loss trend
1. Check feed completeness, units of measure and the reconciliation arithmetic.
2. Repeat a blind physical count; document who counted and when.
3. Compare transactions around the snapshot cutoff, including late receipts and transfers.
4. Review authorised adjustments. Escalate an unexplained residual to Loss Prevention.
5. Record the verified cause and evidence before proposing an adjustment. Theft remains unverified unless separately established.
