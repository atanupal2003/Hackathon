# Scan, transaction errors, negative stock and repeated adjustments
1. Review POS voids, returns and repeated scans against transaction references.
2. Check event ordering, missing sales/receipt feeds and SKU mappings.
3. Inspect adjustment reasons and authorisations; frequent corrections can indicate process errors.
4. Repeat the count and reconcile before attributing a cause.
5. Record findings and request approval for corrections; never treat unusual activity as proof of theft.
