import io
import os
import pandas as pd
import plotly.express as px
import requests
import streamlit as st

st.set_page_config(page_title='Inventory Sentinel AI',page_icon='📦',layout='wide')
API=os.getenv('SENTINEL_API_URL','http://127.0.0.1:8000')
BLUE='#00AEEF'; COLORS=[BLUE,'#17263B','#9464FF','#21B887','#F44949']
st.markdown('''<style>
.block-container {padding-top:1.3rem;max-width:1550px;} h1,h2,h3{color:#101319;}
[data-testid="stMetric"]{border:1px solid #dce6ef;border-radius:5px;padding:15px;background:white;}
[data-testid="stMetricValue"]{color:#00AEEF;} .brand{color:#00AEEF;letter-spacing:5px;font-size:33px;font-weight:500;}
</style>''',unsafe_allow_html=True)
st.markdown('<span class="brand">INVENTORY SENTINEL</span> &nbsp; <b>AI • Executive inventory intelligence</b>',unsafe_allow_html=True)
st.caption('SYNTHETIC DEMO • Persona-based sign-in • No live ERP, WMS or POS connections')

if 'sentinel_token' not in st.session_state: st.session_state.sentinel_token=''
if 'sentinel_user' not in st.session_state: st.session_state.sentinel_user=None
if not st.session_state.sentinel_token:
    st.subheader('Sign in to Inventory Sentinel AI')
    st.write('Your assigned persona determines which workflow actions are permitted.')
    with st.form('persona_login'):
        username=st.text_input('Username',value='manager')
        password=st.text_input('Password',type='password',value='Manager@123')
        submitted=st.form_submit_button('Sign in',type='primary')
    if submitted:
        try:
            r=requests.post(API+'/auth/login',json={'username':username,'password':password},timeout=15)
            if r.ok:
                data=r.json();st.session_state.sentinel_token=data['access_token'];st.session_state.sentinel_user=data['user'];st.rerun()
            else: st.error(r.json().get('detail','Sign-in failed'))
        except requests.RequestException: st.error('Backend unavailable. Start the API using the README instructions.')
    st.info('Local demo accounts: manager / Manager@123 · analyst / Analyst@123 · admin / Admin@123')
    st.stop()
current_user=st.session_state.sentinel_user or {}
role=current_user.get('role','viewer');actor=current_user.get('actor','Demo user')
with st.sidebar:
    st.header('Workspace')
    st.caption(f"Signed in: {current_user.get('persona','User')} ({current_user.get('username','')})")
    if st.button('Sign out'):
        st.session_state.sentinel_token='';st.session_state.sentinel_user=None;st.rerun()
    allowed_pages={'viewer':['Overview','Inventory Risk','Chatbot'],'analyst':['Overview','Inventory Risk','Investigations','Chatbot'],'approver':['Overview','Inventory Risk','Investigations','Chatbot','Resolutions','AI Governance']}.get(role,['Overview','Chatbot'])
    page=st.radio('Navigate',allowed_pages)
    if page!='Chatbot':
        days=st.selectbox('Period (creation cohort)',[30,7,60],format_func=lambda x:f'Last {x} days')
        store=st.selectbox('Location',['All locations','Store 014','Store 027','Store 042','DC North','DC East'])
        category=st.selectbox('Category',['All categories','Womenswear','Menswear','Kidswear'])
        if st.button('Refresh data'):st.rerun()
    else:
        days=30;store='All locations';category='All categories'

params={'days':days}
if store!='All locations':params['store']=store
if category!='All categories':params['category']=category

def api(method,path,**kwargs):
    try:
        response=requests.request(method,API+path,headers={'Authorization':'Bearer '+st.session_state.sentinel_token},timeout=45,**kwargs)
        if not response.ok:
            try:message=response.json().get('detail',response.text)
            except ValueError:message=response.text
            st.error(str(message));return None
        return response.json()
    except requests.RequestException:
        st.error('Backend unavailable. Start the API on port 8000 using the README instructions.');return None

if page=='Chatbot':
    st.title('INVENTORY AI ASSISTANT')
    st.caption('Ask questions about inventory risk and anomaly patterns in your authorized scope. This is a chat facility, not a data table.')
    if 'chat_history' not in st.session_state: st.session_state.chat_history=[('assistant','Hello. I can help interpret inventory aggregates and suggest verification steps. I cannot confirm theft or make stock adjustments.')]
    prompts=['Which categories have the highest anomaly count?','What should I verify for negative stock variance?','Explain the limitations of these anomaly flags.','What evidence should I collect before escalating?']
    with st.sidebar:
        st.subheader('Suggested questions')
        for i,prompt in enumerate(prompts):
            if st.button(prompt,key=f'chat_prompt_{i}'):
                st.session_state.chat_pending=prompt
    for who,text_value in st.session_state.chat_history:
        with st.chat_message(who):st.write(text_value)
    question=st.chat_input('Ask about inventory risk...')
    if question or st.session_state.get('chat_pending'):
        question=question or st.session_state.pop('chat_pending')
        st.session_state.chat_history.append(('user',question))
        with st.chat_message('user'):st.write(question)
        response=api('POST','/chat',json={'question':question})
        answer=response.get('answer','Assistant response unavailable.') if response else 'Assistant response unavailable. Check the API and your access.'
        st.session_state.chat_history.append(('assistant',answer))
        with st.chat_message('assistant'):st.write(answer)
    st.info('Responsible AI: responses may be incomplete. Verify recommendations against source systems.')
    st.stop()

payload=api('GET','/dashboard',params=params)
if payload is None:st.stop()
df=pd.DataFrame(payload['cases']); k=payload['kpis']

def money(value):
    return f'₹{value/10000000:.2f} Cr' if value>=10000000 else f'₹{value/100000:.2f} L' if value>=100000 else f'₹{value:,.0f}'

def percent(value):return 'No data' if value is None else f'{value:.1f}%'

def chart(fig,key,selection_field=None):
    fig.update_layout(colorway=COLORS,paper_bgcolor='white',plot_bgcolor='white',margin=dict(l=10,r=10,t=30,b=20),height=300,legend=dict(orientation='h',y=1.14),font=dict(color='#26384F'))
    fig.update_xaxes(showgrid=False);fig.update_yaxes(gridcolor='#edf2f7')
    if selection_field:
        event=st.plotly_chart(fig,use_container_width=True,key=key,on_select='rerun',selection_mode='points')
        points=event.selection.points
        if points:
            value=points[0].get('customdata',[None])[0]
            if value is not None:
                st.session_state['drill_field']=selection_field;st.session_state['drill_value']=value
                st.caption(f'Selected {value}. Open Inventory Risk to inspect these cases.')
    else:st.plotly_chart(fig,use_container_width=True,key=key)

def table(frame):
    cols=[c for c in ['id','store','category','sku','label','severity','exposure','status','owner','due_at'] if c in frame]
    st.dataframe(frame[cols],use_container_width=True,hide_index=True)

if page=='Overview':
    st.title('EXECUTIVE OVERVIEW')
    st.caption('Inventory risk, business impact and resolution. All measures use the selected case-creation cohort.')
    a,b,c,d=st.columns(4)
    a.metric('Inventory value at risk',money(k['value_at_risk']),f'{k["open_cases"]} open cases',delta_color='off')
    b.metric('Verified loss prevented',money(k['verified_loss_prevented']),'Approved demo outcomes only',delta_color='off')
    c.metric('Inventory accuracy',percent(k['inventory_accuracy']),'Count records within ±1 unit',delta_color='off')
    d.metric('Resolution within SLA',percent(k['within_sla']),'Target 95%',delta_color='off')
    if df.empty:st.info('No cases in this selection.');st.stop()
    df['week']=pd.to_datetime(df['created_at'],utc=True).dt.strftime('%G-W%V')
    a,b=st.columns(2)
    with a:
        st.subheader('Anomaly trend by store')
        trend=df.groupby(['week','store']).size().reset_index(name='New cases')
        chart(px.line(trend,x='week',y='New cases',color='store',markers=True,custom_data=['store'],color_discrete_sequence=COLORS),'store_trend','store')
    with b:
        st.subheader('Anomaly trend by category')
        trend=df.groupby(['week','category']).size().reset_index(name='New cases')
        chart(px.bar(trend,x='week',y='New cases',color='category',barmode='group',custom_data=['category'],color_discrete_sequence=COLORS),'category_trend','category')
    st.caption('Trends count new cases, not currently open cases. Select chart points to drill into Inventory Risk.')
    opened=df[~df.status.isin(['Resolved','Closed'])]
    a,b,c=st.columns([1.2,1.1,1])
    with a:
        st.subheader('Unusual patterns')
        patterns=opened.groupby('label').size().reset_index(name='Open cases')
        chart(px.bar(patterns,x='Open cases',y='label',orientation='h',custom_data=['label'],color_discrete_sequence=[BLUE]),'patterns','label')
        st.info('Suspected causes require verification. The model does not prove theft.')
    with b:
        st.subheader('Risk exposure by location')
        risk=opened.groupby('store').exposure.sum().reset_index().sort_values('exposure')
        chart(px.bar(risk,x='exposure',y='store',orientation='h',custom_data=['store'],labels={'exposure':'Exposure (₹)'},color_discrete_sequence=[BLUE]),'exposure','store')
    with c:
        st.subheader('Resolution performance')
        st.metric('Median resolution',f'{k["median_resolution_hours"]:.1f} hrs' if k['median_resolution_hours'] is not None else 'No resolved cases')
        st.metric('Overdue cases',k['overdue'])
        st.metric('Reviewed alert precision',percent(k['precision']))
        st.caption(f'{k["reviewed_cases"]} reviewed cases. Synthetic outcomes are explicitly recorded in the audit trail.')
    a,b=st.columns([1.7,1])
    with a:
        st.subheader('Priority decisions');table(opened.sort_values('exposure',ascending=False).head(8))
        report=df.drop(columns=['reasons']).to_csv(index=False).encode('utf-8-sig')
        st.download_button('Export selected cohort report',report,'inventory_board_report.csv','text/csv')
    with b:
        st.subheader('Technology & AI assurance')
        st.write('Source mode:',payload['meta'].get('source_mode','Not ingested'))
        st.write('Last ingestion (UTC):',payload['meta'].get('ingested_at','Unknown'))
        st.write('Quality exclusions:',payload['meta'].get('skipped_rows','Unknown'))
        st.write('Stock adjustments: human demo approval')
        st.write('Audit trail: enabled')

elif page=='Inventory Risk':
    st.title('Inventory Risk')
    if df.empty:st.info('No cases.');st.stop()
    if 'drill_field' in st.session_state:
        field=st.session_state['drill_field'];value=st.session_state['drill_value']
        st.info(f'Chart drill-down: {field} = {value}')
        if st.button('Clear chart selection'):
            del st.session_state['drill_field'];del st.session_state['drill_value'];st.rerun()
        df=df[df[field]==value]
    query=st.text_input('Search case ID, SKU or reason')
    severity=st.multiselect('Severity',['High','Medium','Low'],default=['High','Medium','Low'])
    df=df[df.severity.isin(severity)]
    if query:df=df[df.apply(lambda r:query.lower() in str(r.to_dict()).lower(),axis=1)]
    table(df);st.caption('Copy a case ID or open Investigations to review the supporting evidence.')

elif page in ['Investigations','Resolutions']:
    st.title(page)
    if df.empty:st.info('No cases.');st.stop()
    choices=df
    if page=='Resolutions':
        st.caption('Approve verified outcomes and stock corrections. Approval records a demo correction; it does not write to an external inventory system.')
        choices=df[df.status.isin(['Pending approval','Resolved','Closed'])]
    if choices.empty:st.info('No cases at this stage. Use Investigations to progress a case.');st.stop()
    cid=st.selectbox('Case',choices.id.tolist(),format_func=lambda x:f'{x} — {choices.loc[choices.id==x,"store"].iloc[0]} — {choices.loc[choices.id==x,"status"].iloc[0]}')
    case=api('GET',f'/cases/{cid}')
    if case is None:st.stop()
    st.subheader(f'{case["label"]} · {case["sku"]}')
    st.write(f'Status: **{case["status"]}** | Exposure: **{money(case["exposure"])}** | Owner: **{case["owner"]}**')
    for reason in case['reasons']:st.write('• '+reason)
    tabs=st.tabs(['Evidence','Workflow & approval','Audit history'])
    with tabs[0]:
        o=case['observation']
        timeline=[{'Event':label,'Quantity':o[field]} for field,label in [('opening','Opening stock'),('received','Receipt'),('inbound','Transfer in'),('returns','Returns'),('sales','Sales (subtract)'),('outbound','Transfer out (subtract)'),('adjustment','Approved source adjustment'),('expected','Expected closing'),('counted','Physical count'),('variance','Count variance')]]
        st.dataframe(pd.DataFrame(timeline),hide_index=True,use_container_width=True)
        st.json(o)
        st.caption('Daily source quantities are aggregated. Transaction references are available in data/events.csv; source-approved adjustments are distinct from proposed case corrections.')
    with tabs[1]:
        from_states={'New':['Assigned'],'Assigned':['Investigating'],'Investigating':['Pending approval'],'Pending approval':['Resolved','Investigating'],'Resolved':['Closed'],'Closed':[]}
        disabled=role=='viewer' or case['status']=='Closed'
        with st.form('case_update_'+cid):
            owner=st.text_input('Owner',case['owner'],disabled=disabled)
            status=st.selectbox('Next status',[case['status']]+from_states[case['status']],disabled=disabled)
            note=st.text_area('Investigation note',disabled=disabled)
            cause=st.text_input('Verified root cause',case['root_cause'],disabled=disabled or case['status']=='Resolved')
            outcome=st.text_area('Outcome and evidence references',case['outcome'],disabled=disabled or case['status']=='Resolved')
            prevented=st.number_input('Verified loss prevented (₹)',min_value=0.0,max_value=float(case['exposure']),value=float(case['prevented']),disabled=disabled or case['status']=='Resolved')
            adjustment=st.number_input('Proposed stock correction (units)',value=int(case['proposed_adjustment']),step=1,disabled=disabled or case['status']=='Resolved')
            adjustment_reason=st.text_input('Correction justification',case['adjustment_reason'],disabled=disabled or case['status']=='Resolved')
            reviewed=st.checkbox('Evidence reviewed',bool(case['reviewed']),disabled=disabled)
            actionable=st.checkbox('Confirmed actionable alert',bool(case['actionable']),disabled=disabled)
            submitted=st.form_submit_button('Save / approve transition',disabled=disabled)
        if submitted:
            patch={'owner':owner,'status':status,'note':note,'reviewed':int(reviewed),'actionable':int(actionable)}
            if case['status']!='Resolved':patch.update(root_cause=cause,outcome=outcome,prevented=prevented,proposed_adjustment=int(adjustment),adjustment_reason=adjustment_reason)
            result=api('PATCH',f'/cases/{cid}',json=patch)
            if result:st.success('Saved');st.rerun()
        st.caption('New → Assigned → Investigating → Pending approval → Resolved → Closed. Only the approver role can resolve; closed cases are immutable.')
    with tabs[2]:st.dataframe(pd.DataFrame(case['audit']),use_container_width=True,hide_index=True)

else:
    st.title('AI Governance')
    gov=api('GET','/governance')
    if gov is None:st.stop()
    st.metric('Reviewed alert precision',percent(k['precision']))
    st.write('Detection version:',gov['detection_version']);st.write('Prompt version:',gov['prompt_version'])
    st.info(gov['auth']);st.write(gov['refresh'])
    st.subheader('Data health');st.json(payload['meta'])
    st.subheader('AI usage');st.dataframe(pd.DataFrame(gov['usage']),use_container_width=True,hide_index=True)
    st.caption('Local summaries have no token usage. LLM calls record actual token counts when supplied by the provider; costs are not estimated.')
    st.subheader('Audit trail (latest 500 events)');st.dataframe(pd.DataFrame(gov['audit']),use_container_width=True,hide_index=True)
