import tempfile
import unittest
from pathlib import Path
from fastapi.testclient import TestClient
from backend.main import app
from backend import core

class APITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.old=core.DATA;core.DATA=Path(cls.tmp.name)
        core.generate();core.ingest();cls.client=TestClient(app);cls.token=cls.client.post('/auth/login',json={'username':'manager','password':'Manager@123'}).json()['access_token'];cls.analyst_token=cls.client.post('/auth/login',json={'username':'analyst','password':'Analyst@123'}).json()['access_token'];cls.admin_token=cls.client.post('/auth/login',json={'username':'admin','password':'Admin@123'}).json()['access_token']
    @classmethod
    def tearDownClass(cls):core.DATA=cls.old;cls.tmp.cleanup()
    def test_routes_filters_and_access(self):
        self.assertEqual(self.client.get('/health').status_code,200)
        headers={'Authorization':'Bearer '+self.token}
        data=self.client.get('/dashboard',params={'store':'Store 014','days':60},headers=headers).json()
        self.assertTrue(data['cases']);self.assertTrue(all(c['store']=='Store 014' for c in data['cases']))
        cid=data['cases'][0]['id']
        self.assertEqual(self.client.patch('/cases/'+cid,json={'owner':'Me'},headers=headers).status_code,403)
        self.assertEqual(self.client.patch('/cases/'+cid,json={'unexpected':1},headers={'Authorization':'Bearer '+self.analyst_token}) .status_code,422)
        self.assertEqual(self.client.get('/cases/not-found',headers=headers).status_code,404)
        self.assertEqual(self.client.get('/dashboard?days=-1',headers=headers).status_code,422)
        self.assertEqual(self.client.get('/governance',headers=headers).status_code,200)
    def test_login_and_role_tokens(self):
        self.assertEqual(self.client.post('/auth/login',json={'username':'manager','password':'wrong'}).status_code,401)
        self.assertEqual(self.client.get('/dashboard').status_code,401)
        token=self.client.post('/auth/login',json={'username':'admin','password':'Admin@123'}).json()['access_token']
        me=self.client.get('/auth/me',headers={'Authorization':'Bearer '+token}).json()
        self.assertEqual(me['role'],'approver')
    def test_local_assistant(self):
        headers={'Authorization':'Bearer '+self.token}
        cid=self.client.get('/cases?days=60',headers=headers).json()[0]['id']
        response=self.client.post('/cases/'+cid+'/assistant',json={'question':'Verify count'},headers=headers)
        self.assertEqual(response.status_code,200);self.assertTrue(response.json()['sources'])
        self.assertEqual(self.client.get('/governance',headers=headers).json()['usage'][0]['mode'],'Local evidence template')
