import os
import tempfile
import unittest
from backend import core

class WorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.old=core.DATA
        from pathlib import Path
        core.DATA=Path(cls.tmp.name);core.generate();core.ingest()
    @classmethod
    def tearDownClass(cls):core.DATA=cls.old;cls.tmp.cleanup()
    def fresh(self):return next(r for r in core.cases(days=60) if r['status']=='New')
    def test_ingestion_idempotent_and_feed_exclusion(self):
        before=len(core.cases(days=60));result=core.ingest()
        self.assertEqual(result['inserted_cases'],0);self.assertEqual(before,len(core.cases(days=60)))
        with core.connect() as c:
            import json
            ids=[r[0] for r in c.execute('SELECT observation_id FROM cases')]
            for oid in ids:self.assertEqual(int(json.loads(c.execute('SELECT payload FROM observations WHERE id=?',(oid,)).fetchone()[0])['feed_complete']),1)
    def test_viewer_and_invalid_transition_blocked(self):
        cid=self.fresh()['id']
        with self.assertRaises(PermissionError):core.update(cid,'viewer','viewer',{'owner':'me'})
        with self.assertRaises(ValueError):core.update(cid,'analyst','analyst',{'status':'Resolved'})
    def test_approval_and_kpi(self):
        r=self.fresh();cid=r['id']
        core.update(cid,'analyst','analyst',{'status':'Assigned','owner':'Operations'})
        core.update(cid,'analyst','analyst',{'status':'Investigating'})
        core.update(cid,'analyst','analyst',{'status':'Pending approval','root_cause':'Count error','outcome':'Recount evidence REF-001','prevented':r['exposure'],'proposed_adjustment':2,'adjustment_reason':'Confirmed recount','reviewed':1,'actionable':1})
        with self.assertRaises(PermissionError):core.update(cid,'analyst','analyst',{'status':'Resolved'})
        approved=core.update(cid,'approver','approver',{'status':'Resolved'})
        self.assertEqual(approved['adjustment_approved'],1)
        self.assertEqual(core.dashboard(days=60)['kpis']['verified_loss_prevented'],r['exposure'])
        core.update(cid,'approver','approver',{'status':'Closed'})
        with self.assertRaises(ValueError):core.update(cid,'approver','approver',{'owner':'Changed'})
    def test_financial_validation(self):
        r=self.fresh()
        with self.assertRaises(ValueError):core.update(r['id'],'analyst','analyst',{'prevented':r['exposure']+1})
        with self.assertRaises(ValueError):core.update(r['id'],'analyst','analyst',{'actionable':1,'reviewed':0})
    def test_overlap_exposure_not_added(self):
        row={'opening':20,'received':0,'inbound':0,'returns':0,'adjustment':-15,'sales':40,'outbound':0,'counted':0,'dispatched':20,'adjustment_count':4,'voids':12,'feed_complete':1,'uom':'EA','unit_cost':100}
        _,_,labels,_,risk=core.detect(row,[])
        self.assertGreater(len(labels),2);self.assertEqual(risk,3500)
    def test_baseline_uses_history(self):
        row={'opening':100,'received':0,'inbound':0,'returns':0,'adjustment':0,'sales':0,'outbound':0,'counted':92,'dispatched':0,'adjustment_count':0,'voids':0,'feed_complete':1,'uom':'EA','unit_cost':100}
        self.assertIn(core.LABELS[5],core.detect(row,[0]*14)[2]);self.assertEqual(core.detect(row,[])[2],[])

if __name__=='__main__':unittest.main()
