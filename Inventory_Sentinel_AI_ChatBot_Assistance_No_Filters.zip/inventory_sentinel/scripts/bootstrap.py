import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from backend.core import generate,ingest,seed_demo_outcomes
if __name__=='__main__':
    print('Generated observations:',generate())
    print('Detection:',ingest())
    seed_demo_outcomes()
    print('Ready. Re-running ingestion preserves existing case status and audit history.')
