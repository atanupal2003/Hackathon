"""Run after starting the API; verifies all five screens with Streamlit AppTest."""
from pathlib import Path
from streamlit.testing.v1 import AppTest
app=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'frontend/app.py'),default_timeout=20).run()
for page in ['Overview','Inventory Risk','Investigations','Resolutions','AI Governance']:
    app.sidebar.radio[0].set_value(page).run()
    if app.exception:raise RuntimeError([str(e.value) for e in app.exception])
    print(page,'PASS')
