"""Serve the custom executive interface and REST API together, on loopback."""
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if __name__=='__main__':
    process=subprocess.Popen([sys.executable,'-m','uvicorn','backend.main:app','--host','127.0.0.1','--port','8000'],cwd=ROOT)
    print('Executive dashboard: http://localhost:8000 | API docs: http://localhost:8000/docs | Ctrl+C to stop',flush=True)
    try:process.wait()
    except KeyboardInterrupt:
        if process.poll() is None:process.terminate()
        try:process.wait(timeout=5)
        except subprocess.TimeoutExpired:process.kill()
