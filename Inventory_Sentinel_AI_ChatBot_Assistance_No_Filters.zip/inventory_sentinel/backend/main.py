from contextlib import asynccontextmanager
from typing import Literal
import os, time, json, hmac, hashlib, base64
from fastapi import FastAPI, HTTPException, Header, Depends, Request
from pydantic import BaseModel, Field, ConfigDict
from . import core
from .assistant import investigate

@asynccontextmanager
async def lifespan(app):
    core.schema()
    yield

app=FastAPI(title='Inventory Sentinel AI',version='1.0.0',lifespan=lifespan)

# Local demo accounts. Configure unique credentials and a strong SENTINEL_AUTH_SECRET outside demos.
# Production deployments should use Entra ID/OIDC and a managed identity provider.
AUTH_SECRET=os.getenv('SENTINEL_AUTH_SECRET','local-demo-only-change-this-secret').encode()
DEMO_USERS={
    os.getenv('SENTINEL_MANAGER_USER','manager'): {'password':os.getenv('SENTINEL_MANAGER_PASSWORD','Manager@123'),'actor':'Store Manager','role':'viewer','persona':'Store Manager / Viewer'},
    os.getenv('SENTINEL_ANALYST_USER','analyst'): {'password':os.getenv('SENTINEL_ANALYST_PASSWORD','Analyst@123'),'actor':'Loss Prevention Analyst','role':'analyst','persona':'Warehouse Supervisor / Loss Prevention Analyst'},
    os.getenv('SENTINEL_ADMIN_USER','admin'): {'password':os.getenv('SENTINEL_ADMIN_PASSWORD','Admin@123'),'actor':'Administrator','role':'approver','persona':'Administrator / Approver'},
}
def _b64(data:bytes)->str:return base64.urlsafe_b64encode(data).decode().rstrip('=')
def _token_for(user:str,record:dict)->str:
    payload=_b64(json.dumps({'sub':user,'actor':record['actor'],'role':record['role'],'persona':record['persona'],'exp':int(time.time())+8*3600},separators=(',',':')).encode())
    sig=_b64(hmac.new(AUTH_SECRET,payload.encode(),hashlib.sha256).digest())
    return payload+'.'+sig
def _claims(token:str):
    try:
        payload,sig=token.split('.',1); expected=_b64(hmac.new(AUTH_SECRET,payload.encode(),hashlib.sha256).digest())
        if not hmac.compare_digest(sig,expected): return None
        data=json.loads(base64.urlsafe_b64decode(payload+'='*((4-len(payload)%4)%4)))
        if int(data.get('exp',0))<int(time.time()) or data.get('role') not in ['viewer','analyst','approver']: return None
        return data
    except Exception:return None
class LoginRequest(BaseModel):
    username:str=Field(...,min_length=1,max_length=80)
    password:str=Field(...,min_length=1,max_length=200)
@app.post('/auth/login')
def login(request:LoginRequest):
    record=DEMO_USERS.get(request.username)
    if not record or not hmac.compare_digest(request.password,record['password']): raise HTTPException(401,'Invalid username or password')
    return {'access_token':_token_for(request.username,record),'token_type':'bearer','expires_in':28800,'user':{'username':request.username,'actor':record['actor'],'role':record['role'],'persona':record['persona']}}
@app.get('/auth/me')
def me(authorization:str|None=Header(None)):
    claims=_claims(authorization[7:].strip()) if authorization and authorization.lower().startswith('bearer ') else None
    if not claims:raise HTTPException(401,'Login required or session expired')
    return {'username':claims['sub'],'actor':claims['actor'],'role':claims['role'],'persona':claims['persona']}
def identity(authorization: str|None=Header(None)):
    claims=_claims(authorization[7:].strip()) if authorization and authorization.lower().startswith('bearer ') else None
    if not claims:raise HTTPException(401,'Login required or session expired')
    return claims['actor'],claims['role']
@app.middleware('http')
async def require_login(request:Request,call_next):
    protected=request.url.path.startswith(('/dashboard','/cases','/chat','/governance','/model-info'))
    if protected:
        header=request.headers.get('authorization','')
        claims=_claims(header[7:].strip()) if header.lower().startswith('bearer ') else None
        if not claims:return __import__('starlette.responses',fromlist=['JSONResponse']).JSONResponse({'detail':'Login required or session expired'},status_code=401)
    return await call_next(request)

class CasePatch(BaseModel):
    model_config=ConfigDict(extra='forbid')
    status: Literal['New','Assigned','Investigating','Pending approval','Resolved','Closed']|None=None
    owner:str|None=None
    root_cause:str|None=None
    outcome:str|None=None
    prevented:float|None=Field(None,ge=0)
    reviewed:Literal[0,1]|None=None
    actionable:Literal[0,1]|None=None
    proposed_adjustment:int|None=None
    adjustment_reason:str|None=None
    note:str|None=None

class Question(BaseModel):
    question:str=Field('What should I verify next?',min_length=1,max_length=2000)

class ChatQuestion(BaseModel):
    question:str=Field(...,min_length=1,max_length=1200)

def guardrail_check(question:str):
    q=question.lower()
    blocked = [
        'ignore all previous instructions', 'reveal system prompt', 'show api key',
        'dump secrets', 'bypass access', 'disable guardrail', 'delete audit',
        'approve stock adjustment', 'execute stock adjustment', 'mark as theft',
        'identify the thief', 'prove theft'
    ]
    if any(term in q for term in blocked):
        raise HTTPException(422, 'Guardrail blocked this request. The assistant cannot bypass controls, reveal secrets, accuse individuals, or approve/execute inventory changes.')
    return question.strip()

@app.get('/model-info')
def model_info():
    with core.connect() as c:
        row=c.execute("SELECT value FROM meta WHERE key='isolation_forest'").fetchone()
    try:
        ml = __import__('json').loads(row[0]) if row else {'enabled': False, 'reason': 'Run ingestion to fit the model.'}
    except Exception:
        ml = {'enabled': False, 'reason': 'Model metadata is not available.'}
    return {
        'current_detector': 'Isolation Forest + reconciliation rules + trailing statistical baseline',
        'isolation_forest': ml,
        'rules': [
            'Stock reconciliation variance and receipt mismatch',
            'Repeated inventory adjustments',
            'Negative reconciled stock',
            'High POS void counts',
            'Trailing baseline threshold for unusual variance'
        ],
        'note': 'Isolation Forest is fitted during batch ingestion when scikit-learn is installed and at least 30 complete observations are available. Model scores are anomaly indicators, not probabilities or proof of theft.'
    }

@app.get('/health')
def health():return {'status':'ok','mode':'synthetic demo','auth':'persona login with signed 8-hour demo token'}

@app.get('/dashboard')
def dashboard(store:str|None=None,category:str|None=None,days:int=30):
    if days not in [7,30,60]:raise HTTPException(422,'days must be 7, 30 or 60')
    return core.dashboard(store,category,days)

@app.get('/cases')
def cases(store:str|None=None,category:str|None=None,days:int=30):return core.cases(store,category,days)

@app.get('/cases/{cid}')
def detail(cid:str):
    try:return core.detail(cid)
    except ValueError as e:raise HTTPException(404,str(e))

@app.patch('/cases/{cid}')
def update(cid:str,patch:CasePatch,who=Depends(identity)):
    try:return core.update(cid,*who,patch.model_dump(exclude_none=True))
    except PermissionError as e:raise HTTPException(403,str(e))
    except ValueError as e:raise HTTPException(400,str(e))

@app.post('/cases/{cid}/assistant')
def assistant(cid:str,q:Question):
    try:return investigate(cid,q.question)
    except ValueError as e:raise HTTPException(404,str(e))
    except Exception:raise HTTPException(503,'Assistant unavailable; check optional dependencies/configuration or disable optional integrations.')



@app.post('/chat')
def chat(q:ChatQuestion, who=Depends(identity)):
    question=guardrail_check(q.question)
    # Safe-by-default assistant: answer from approved inventory case summaries and playbooks only.
    from .assistant import answer_general
    try:
        return answer_general(question, actor=who[0], role=who[1])
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(503,'Assistant unavailable; check configuration or optional integrations.')

@app.get('/governance')
def governance():
    with core.connect() as c:
        usage=[dict(r) for r in c.execute('SELECT * FROM usage ORDER BY id DESC LIMIT 100')]
        audit=[dict(r) for r in c.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 500')]
    return {'usage':usage,'audit':audit,'detection_version':'isolation-forest-plus-rules-v1','prompt_version':'investigation-v1','auth':'Signed persona login for local demo; use Entra ID/OIDC in production','refresh':'Manual CSV ingestion; no live ERP/WMS/POS connection'}

# Custom executive interface. Assets are local: no CDN/network needed for presentation.
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
app.mount('/web', StaticFiles(directory=str(core.ROOT/'frontend'/'web')), name='web')

@app.get('/', include_in_schema=False)
def executive_ui():
    return FileResponse(core.ROOT/'frontend'/'web'/'index.html')
