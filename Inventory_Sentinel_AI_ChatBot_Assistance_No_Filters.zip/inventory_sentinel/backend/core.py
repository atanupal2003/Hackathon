"""Deterministic ingestion, detection and case service. No external dependencies."""
import csv
import hashlib
import json
import os
import random
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = Path(os.getenv('SENTINEL_DATA_DIR', str(ROOT / 'data')))
STATES = ['New', 'Assigned', 'Investigating', 'Pending approval', 'Resolved', 'Closed']
TRANSITIONS = {'New':['Assigned'], 'Assigned':['Investigating'], 'Investigating':['Pending approval'], 'Pending approval':['Resolved','Investigating'], 'Resolved':['Closed'], 'Closed':[]}
LABELS = ['Shrinkage / unexplained loss','Receipt mismatch','Repeated adjustments','Negative stock','Scan / transaction errors','Unusual loss trend']

def now():
    return datetime.now(timezone.utc).isoformat()

def connect():
    DATA.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DATA / 'sentinel.db')
    con.row_factory = sqlite3.Row
    return con

def schema():
    with connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS observations(id TEXT PRIMARY KEY, payload TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS cases(id TEXT PRIMARY KEY, observation_id TEXT UNIQUE, store TEXT, category TEXT, sku TEXT, created_at TEXT, due_at TEXT, status TEXT, owner TEXT, severity TEXT, label TEXT, exposure REAL, reasons TEXT, root_cause TEXT DEFAULT '', outcome TEXT DEFAULT '', prevented REAL DEFAULT 0, resolved_at TEXT, proposed_adjustment INTEGER DEFAULT 0, adjustment_approved INTEGER DEFAULT 0, adjustment_reason TEXT DEFAULT '', reviewed INTEGER DEFAULT 0, actionable INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, case_id TEXT, actor TEXT, role TEXT, action TEXT, details TEXT, timestamp TEXT);
        CREATE TABLE IF NOT EXISTS usage(id INTEGER PRIMARY KEY, case_id TEXT, mode TEXT, model TEXT, prompt_version TEXT, input_tokens INTEGER, output_tokens INTEGER, timestamp TEXT);
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
        ''')

def write_csv(name, rows):
    with (DATA / name).open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def generate(seed=42):
    """56 days × 5 locations × 12 SKUs; injected signals are synthetic, never theft proof."""
    DATA.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    stores = ['Store 014','Store 027','Store 042','DC North','DC East']
    products = [{'sku':f'SKU{i:04}', 'category':['Womenswear','Menswear','Kidswear'][i%3], 'unit_cost':200+i*75, 'uom':'EA'} for i in range(1,13)]
    start = datetime.now(timezone.utc).date()-timedelta(days=55)
    rows=[]; events=[]; truth=[]
    for day in range(56):
        for store in stores:
            for p in products:
                opening=rng.randint(80,300); received=rng.randint(0,30); inbound=rng.randint(0,8)
                returns=rng.randint(0,3); sales=rng.randint(5,40); outbound=rng.randint(0,8)
                adjustment=0; adjust_count=0; voids=rng.randint(0,2); dispatched=received
                pattern='Normal'; missing=False
                # Deterministic injection across dates and stores; one reconciled observation per SKU/day.
                n=rng.random()
                loss=0
                if n<.018: loss=rng.randint(12,35); pattern=LABELS[0]
                elif n<.030: dispatched=received+15; pattern=LABELS[1]
                elif n<.040: adjustment=-12; adjust_count=4; pattern=LABELS[2]
                elif n<.045: opening=5; sales=40; pattern=LABELS[3]
                elif n<.055: voids=12; pattern=LABELS[4]
                elif n<.065: loss=8; pattern=LABELS[5]
                elif n<.070: missing=True; pattern='Feed delay'
                expected=opening+received+inbound+returns-sales-outbound+adjustment
                counted=max(0,expected-loss)
                oid=f'{start+timedelta(days=day)}|{store}|{p["sku"]}'
                row=dict(id=oid,date=str(start+timedelta(days=day)),store=store,sku=p['sku'],category=p['category'],unit_cost=p['unit_cost'],uom='EA',opening=opening,received=received,inbound=inbound,returns=returns,sales=sales,outbound=outbound,adjustment=adjustment,adjustment_count=adjust_count,dispatched=dispatched,counted=counted,voids=voids,feed_complete=int(not missing),count_verified=1)
                rows.append(row); truth.append({'observation_id':oid,'injected_pattern':pattern})
                for kind,qty in [('Opening stock',opening),('Goods receipt',received),('Transfer in',inbound),('Customer return',returns),('POS sale',-sales),('Transfer out',-outbound),('Approved adjustment',adjustment),('Physical count',counted)]:
                    events.append({'observation_id':oid,'date':row['date'],'store':store,'sku':p['sku'],'event_type':kind,'quantity':qty,'reference':hashlib.sha256((oid+kind).encode()).hexdigest()[:12]})
    write_csv('inventory_daily.csv',rows); write_csv('events.csv',events)
    write_csv('products.csv',products); write_csv('locations.csv',[{'store':s,'type':'DC' if s.startswith('DC') else 'Store'} for s in stores]);write_csv('ground_truth.csv',truth)
    return len(rows)

def detect(row, history):
    expected=sum(float(row[k]) for k in ['opening','received','inbound','returns','adjustment'])-float(row['sales'])-float(row['outbound'])
    gap=float(row['counted'])-expected
    reasons=[]; labels=[]; risks=[]
    if not int(row['feed_complete']) or row['uom']!='EA': return expected,gap,[],[],0
    cost=float(row['unit_cost'])
    if abs(gap)>=10:
        labels.append(LABELS[0]); reasons.append(f'Physical count variance {gap:g} units; expected {expected:g}, counted {row["counted"]}.'); risks.append(abs(gap)*cost)
    receipt_gap=float(row['dispatched'])-float(row['received'])
    if receipt_gap>=10:
        labels.append(LABELS[1]); reasons.append(f'Dispatch exceeds receipt by {receipt_gap:g} units.');risks.append(receipt_gap*cost)
    if int(row['adjustment_count'])>=3 and abs(float(row['adjustment']))>=10:
        labels.append(LABELS[2]); reasons.append(f'{row["adjustment_count"]} adjustments with net {row["adjustment"]} units.');risks.append(abs(float(row['adjustment']))*cost)
    if expected<0:
        labels.append(LABELS[3]); reasons.append(f'Reconciled system stock is negative ({expected:g}).');risks.append(abs(expected)*cost)
    if int(row['voids'])>=10:
        labels.append(LABELS[4]); reasons.append(f'{row["voids"]} POS voids; review transaction evidence.');risks.append(0)
    # Prior complete observations only; no future leakage.
    if len(history)>=14:
        mean=sum(history)/len(history); variance=sum((x-mean)**2 for x in history)/len(history)
        threshold=max(5,mean+3*variance**.5)
        if abs(gap)>threshold and abs(gap)<10:
            labels.append(LABELS[5]); reasons.append(f'Variance {abs(gap):g} exceeds trailing baseline threshold {threshold:.1f} units.');risks.append(abs(gap)*cost)
    return expected,gap,labels,reasons,max(risks,default=0)

def ingest():
    schema(); history={}; seen=set(); skipped=0; inserted=0
    with (DATA/'inventory_daily.csv').open(encoding='utf-8') as f: rows=list(csv.DictReader(f))
    rows.sort(key=lambda r:r['date'])
    with connect() as c:
        for r in rows:
            if r['id'] in seen: skipped+=1; continue
            seen.add(r['id']); key=(r['store'],r['sku'])
            past=history.setdefault(key,[])
            expected,gap,labels,reasons,risk=detect(r,past[-28:])
            if int(r['feed_complete']):past.append(abs(gap))
            else:skipped+=1
            r.update(expected=expected,variance=gap)
            c.execute('INSERT OR REPLACE INTO observations VALUES (?,?)',(r['id'],json.dumps(r)))
            if not labels: continue
            cid='CASE-'+hashlib.sha256(r['id'].encode()).hexdigest()[:10].upper()
            created=r['date']+'T09:00:00+00:00'; severity='High' if risk>=15000 else 'Medium' if risk>=5000 else 'Low'
            due=(datetime.fromisoformat(created)+timedelta(hours=24 if severity=='High' else 48)).isoformat()
            cur=c.execute('INSERT OR IGNORE INTO cases(id,observation_id,store,category,sku,created_at,due_at,status,owner,severity,label,exposure,reasons) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',(cid,r['id'],r['store'],r['category'],r['sku'],created,due,'New','Unassigned',severity,labels[0],risk,json.dumps(reasons)))
            if cur.rowcount: inserted+=1; audit(c,cid,'pipeline','system','Detected',json.dumps(labels))
        for k,v in {'ingested_at':now(),'skipped_rows':str(skipped),'observation_count':str(len(seen)),'source_mode':'Synthetic batch; refresh manually'}.items():c.execute('INSERT OR REPLACE INTO meta VALUES (?,?)',(k,v))
    return {'inserted_cases':inserted,'observations':len(seen),'quality_exclusions':skipped}

def audit(c,cid,actor,role,action,details):
    c.execute('INSERT INTO audit(case_id,actor,role,action,details,timestamp) VALUES (?,?,?,?,?,?)',(cid,actor,role,action,details,now()))

def cases(store=None,category=None,days=30):
    cutoff=(datetime.now(timezone.utc)-timedelta(days=days)).isoformat()
    with connect() as c:
        rows=[dict(r) for r in c.execute('SELECT * FROM cases WHERE created_at>=? ORDER BY created_at DESC',(cutoff,))]
    for r in rows:r['reasons']=json.loads(r['reasons'])
    return [r for r in rows if (not store or r['store']==store) and (not category or r['category']==category)]

def detail(cid):
    with connect() as c:
        r=c.execute('SELECT * FROM cases WHERE id=?',(cid,)).fetchone()
        if not r:raise ValueError('Case not found')
        d=dict(r); d['reasons']=json.loads(d['reasons'])
        d['observation']=json.loads(c.execute('SELECT payload FROM observations WHERE id=?',(d['observation_id'],)).fetchone()[0])
        d['audit']=[dict(r) for r in c.execute('SELECT * FROM audit WHERE case_id=? ORDER BY id',(cid,))]
    return d

def update(cid,actor,role,changes):
    if role not in ['analyst','approver']:raise PermissionError('Viewer access is read-only')
    if not actor.strip():raise ValueError('Actor is required')
    allowed={'status','owner','root_cause','outcome','prevented','reviewed','actionable','proposed_adjustment','adjustment_reason'}
    if set(changes)-allowed-{'note'}:raise ValueError('Unsupported field')
    # Fetch and validate inside the same write transaction to avoid concurrent stale approvals.
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        raw=c.execute('SELECT * FROM cases WHERE id=?',(cid,)).fetchone()
        if not raw:raise ValueError('Case not found')
        d=dict(raw); merged=d|changes
        if d['status']=='Closed':raise ValueError('Closed cases are immutable')
        target=changes.get('status',d['status'])
        if target!=d['status'] and target not in TRANSITIONS[d['status']]:raise ValueError('Invalid lifecycle transition')
        if target=='Assigned' and merged['owner'].strip() in ['', 'Unassigned']:raise ValueError('Assign an owner first')
        if any(k in changes for k in ['prevented','root_cause','outcome','proposed_adjustment','adjustment_reason']) and d['status']=='Resolved':raise ValueError('Resolved financial/evidence fields are immutable')
        if merged['prevented']<0 or merged['prevented']>d['exposure']:raise ValueError('Verified prevention must be between zero and case exposure')
        if merged['actionable'] and not merged['reviewed']:raise ValueError('Actionable requires reviewed status')
        if target=='Resolved' and d['status']!='Resolved':
            if role!='approver':raise PermissionError('Approver role required')
            if not merged['root_cause'].strip() or not merged['outcome'].strip():raise ValueError('Verified cause and outcome evidence are required')
            if merged['proposed_adjustment'] and not merged['adjustment_reason'].strip():raise ValueError('Adjustment justification required')
            changes=changes|{'resolved_at':now(),'adjustment_approved':int(bool(merged['proposed_adjustment']))}
        for key,value in changes.items():
            if key=='note':continue
            if key not in allowed|{'resolved_at','adjustment_approved'}:raise ValueError('Unsupported field')
            c.execute(f'UPDATE cases SET {key}=? WHERE id=?',(value,cid))
        audit(c,cid,actor,role,'Case updated',json.dumps(changes))
    return detail(cid)

def dashboard(store=None,category=None,days=30):
    selected=cases(store,category,days); opened=[r for r in selected if r['status'] not in ['Resolved','Closed']]
    resolved=[r for r in selected if r['resolved_at']]
    reviewed=[r for r in selected if r['reviewed']]
    with connect() as c:
        obs=[json.loads(r[0]) for r in c.execute('SELECT payload FROM observations')]
        meta=dict(c.execute('SELECT key,value FROM meta').fetchall())
    cutoff=str(datetime.now(timezone.utc).date()-timedelta(days=days-1))
    obs=[r for r in obs if r['date']>=cutoff and int(r['feed_complete']) and (not store or r['store']==store) and (not category or r['category']==category)]
    counted=[r for r in obs if int(r['count_verified'])]
    hours=sorted((datetime.fromisoformat(r['resolved_at'])-datetime.fromisoformat(r['created_at'])).total_seconds()/3600 for r in resolved)
    n=len(hours); median=(hours[n//2] if n%2 else (hours[n//2-1]+hours[n//2])/2) if n else None
    return {'cases':selected,'kpis':{'value_at_risk':sum(r['exposure'] for r in opened),'open_cases':len(opened),'verified_loss_prevented':sum(r['prevented'] for r in resolved),'inventory_accuracy':100*sum(abs(r['variance'])<=1 for r in counted)/len(counted) if counted else None,'within_sla':100*sum(r['resolved_at']<=r['due_at'] for r in resolved)/len(resolved) if resolved else None,'median_resolution_hours':median,'overdue':sum(r['due_at']<now() for r in opened),'precision':100*sum(r['actionable'] for r in reviewed)/len(reviewed) if reviewed else None,'reviewed_cases':len(reviewed)},'meta':meta}

def seed_demo_outcomes():
    """Exercise workflows with clearly synthetic approvals; dates remain honest."""
    for i,r in enumerate(cases(days=60)[:24]):
        if r['status']!='New':continue
        update(r['id'],'Demo analyst','analyst',{'owner':'Store Operations','status':'Assigned'})
        update(r['id'],'Demo analyst','analyst',{'status':'Investigating','reviewed':1,'actionable':int(i%4!=0),'note':'Synthetic evidence reviewed for demonstration.'})
        if i%3==0:continue
        update(r['id'],'Demo analyst','analyst',{'status':'Pending approval','root_cause':'Synthetic receipt/count discrepancy verified','outcome':'Demo recount and reconciliation evidence recorded','prevented':r['exposure']*.5 if i%4!=0 else 0})
        update(r['id'],'Demo approver','approver',{'status':'Resolved'})
        if i%2==0:update(r['id'],'Demo approver','approver',{'status':'Closed'})
