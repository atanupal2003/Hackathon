# Synthetic data and KPI contract

| File | Grain / contents |
|---|---|
| inventory_daily.csv | One date/location/SKU snapshot; unique `id` |
| events.csv | Eight daily aggregate evidence events per snapshot, with deterministic reference IDs; not raw individual POS transactions |
| products.csv | SKU/category/unit cost/unit of measure |
| locations.csv | Location/type |
| ground_truth.csv | Synthetic injection label per observation; evaluation only |
| sentinel.db | Observations, cases, audit, assistant usage and ingestion metadata |

Fields: opening, received, inbound, returns, sales, outbound, adjustment and counted are quantities in EA. Sales/outbound are stored positive and subtracted; adjustment is signed. Dispatched is matched to the daily receipt in this simplified synthetic source. Adjustment_count and voids represent aggregate activity. Unit_cost is synthetic INR acquisition cost, not retail price. Feed_complete=0 defers detection; count_verified=1 identifies completed synthetic counts.

| KPI | Implemented definition |
|---|---|
| Value at risk | Sum exposure of selected cohort cases outside Resolved/Closed |
| Verified loss prevented | Sum approver-resolved cohort cases' recorded prevented amount, constrained to case exposure |
| Inventory accuracy | Percentage of complete verified daily count records with absolute variance ≤1 unit; record-based, not quantity-weighted |
| Resolution within SLA | Resolved cases with resolved_at ≤ due_at / all resolved cohort cases |
| Median resolution | Median hours from creation to approval-resolution |
| Overdue | Open cohort cases whose deadline has passed |
| Reviewed precision | Actionable reviewed cases / all reviewed cohort cases; user labels, not ground truth |
| Trends | New grouped cases by creation week/store/category |
| Patterns | Open cases by primary detector label, not verified cause |

Filters apply to case **creation dates**, not all activity within a resolution date period. Counts and exposure use the same selected cohort. Accuracy uses source observation dates. No prior-period accuracy delta is fabricated. Exact chart values will vary with seed/date and workflow updates.

Rule thresholds: count variance ≥10 units; receipt shortage ≥10; ≥3 adjustments and ≥10 net units; negative reconciled stock; ≥10 voids; small absolute variance >max(5, trailing mean+3×population standard deviation) with ≥14 prior observations. Rule order determines primary label; every supporting reason remains visible. Exposure is max of overlapping rule estimates; scan-only cases have zero financial estimate. Thresholds require tuning against real operational volumes.
