# Validation performed

Python 3.12 runtime. Eight functional tests passed using `python -m unittest discover -s tests -v`. All five screens rendered without runtime exceptions using Streamlit AppTest against the running FastAPI service. The optional OpenAI and Chroma integrations were not exercised; they require optional dependencies and provider configuration.

Generated fixture: 3,360 observations, 26,880 daily aggregate events, 202 detected cases and 13 incomplete-feed exclusions. Detection is repeatable for a fixed seed/date. Eight tests exercise data exclusion, idempotence, baselines, overlapping exposure, case approval, access restrictions, financial validation, cohort filters and local playbook retrieval.

Installed core package versions: FastAPI 0.143.0, uvicorn 0.54.0, Streamlit 1.65.0, pandas 2.2.3, Plotly 6.9.0, requests 2.34.2, Pydantic 2.13.5, httpx 0.28.1. `requirements.txt` pins these tested direct dependencies; transitive dependencies are resolved by pip on your machine.

To reproduce screen smoke checks, start the API, then run `python scripts/smoke_ui.py` with the virtual-environment interpreter. These are runtime checks, not a visual pixel-match assertion or browser-based usability test. The visual theme approximates the supplied concept; screenshot numeric values are not hardcoded.

## Executive presentation revision

The custom executive UI was rendered in a real headless Chromium browser at 1536 × 1024 and visually compared with the supplied concept. Browser interactions exercised presentation/working-data switching, the risk table, case evidence, assistant retrieval, resolution queue and governance audit table, with no JavaScript page errors. The eight domain/API tests also passed after adding static UI serving. Browser viewport checks covered desktop and mobile layouts. The old Streamlit screen remains as a prototype; the new default is the custom interface at port 8000.
