# CIO / CTO presentation guide

## Start

Open the project root in VS Code and run the standard setup and `scripts/run_demo.py`. Open **http://localhost:8000**. The former Streamlit interface at port 8501 is retained only as a prototype and does not reproduce the executive reference.

The executive interface is custom local HTML/CSS/JavaScript served by FastAPI; there is no Node installation/build step for running it. Present at browser zoom 100% with a 1536 × 1024 desktop viewport for the closest match to the supplied concept.

## Reference view

Default **Illustrative presentation view** reproduces the reference's layout, aqua-blue/white palette, KPI text/figures, charts, triage patterns, priority decisions and control-status panel. It is visibly labelled **CONCEPT MOCKUP • ILLUSTRATIVE DATA**. Its numbers and feed-health status are visual reference values, not computed operational results. Filters are disabled in this view because the image contains only a single illustrative cohort. The text-rendered wordmark and system Arial font approximate the reference; proprietary font/logo files are not bundled.

## Working view

Click **Switch to working data** at the bottom to display actual computed synthetic metrics and activate filters. Navigation and drill-down switch to working-data screens; the transition is labelled. Here the case state machine, role checks, evidence, assistant, approvals, audit and governance operate against SQLite. Actual values intentionally differ from the reference.

## Suggested five-minute demonstration

1. Explain business risk and resolution from the reference view, explicitly noting illustrative data.
2. Switch to working data and filter one store/category.
3. Select a trend point or a priority decision to review its source evidence.
4. Open demo settings with the profile icon; choose analyst to assign and investigate a case.
5. Record findings, move to Pending approval, choose approver and resolve it.
6. Show governance/audit history; return to Overview and presentation view if desired.

Bell icon opens overdue cases. Search opens a filtered inventory-risk table. Decision buttons open case review; they do not automatically authorise stock changes. Proposed corrections are recorded in the local demo, not written to a real ERP.

## Board report

On Overview, **Export board report** opens print. Choose Save as PDF, landscape, A3, background graphics enabled. The print stylesheet removes navigation/control tools and keeps executive cards, graphs and tables. Other screens export case CSV.
