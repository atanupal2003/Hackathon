# Implemented MVP and next development steps

| Plan area | Included implementation | Production extension |
|---|---|---|
| Data foundation | Reproducible CSV generation, masters, daily events, SQLite ingestion, source exclusions | ERP/WMS/POS adapters, transit/timezone/UOM contracts, quarantine and schema validation |
| Detection | Five rules + trailing baseline, explainable evidence, same-observation grouping | Store/category-normalised baselines, cross-day incident identity, backtesting |
| Case lifecycle | Owner, state machine, reviewed labels, outcome/evidence, human demo approval | Verified SSO, separation of duties, immutable external audit retention |
| Five screens | Custom executive HTML/CSS/JS interface: Overview, Risk, Investigations, Resolutions, Governance | Production web UI and accessibility/performance hardening |
| AI assistant | Local evidence summary, playbooks, optional direct Chroma and external LLM | Approved embeddings, citation evaluations, prompt-injection tests and cost alerts |
| Reports | Filtered cohort CSV export | Browser print/PDF executive export included; automated distribution remains future work |
| Assurance | Real timestamps, quality exclusions, audit logs, token usage | Live monitoring, alert delivery, SLAs, recovery drills |
| Validation | Domain + API tests and UI smoke tests | Business UAT, security/load tests and source reconciliation sign-off |

Suggested sequence: agree KPI contracts → integrate one real source/location → validate stock arithmetic → replay known incidents → calibrate detection → configure verified identity and approvals → pilot with operations → expand locations. Keep all inventory writes under an independently verified approval process.

Future scheduled ingestion can execute `scripts/ingest.py` using Windows Task Scheduler or an orchestrator. It is not enabled by this demo, and source CSVs are snapshots rather than a live feed.
