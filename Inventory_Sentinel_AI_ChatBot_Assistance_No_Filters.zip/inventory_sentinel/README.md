# Inventory Sentinel AI — Executive Presentation Edition

A runnable local MVP with a custom executive dashboard reproducing the agreed aqua-blue/white concept layout. **All data and seeded investigation outcomes are synthetic.** It contains five screens, reconciled stock, explainable rules, a trailing statistical baseline, case workflows, human demo approvals, audit history, board-report CSV export and an evidence-grounded assistant. No MCP server/client/dependency/endpoint.

## 1. Install prerequisites

Use **Python 3.11 or 3.12** and VS Code. In VS Code Extensions install **Python** and **Python Debugger** (Microsoft). You do not need Node.js, Docker, Databricks or an API key.

## 2. Extract and open the project

Extract the ZIP to, for example, `C:\Primark_Predator\inventory_sentinel`. Open VS Code → **File → Open Folder** → select the folder that directly contains this README, `backend`, `frontend` and `requirements.txt`.

Open **Terminal → New Terminal**. These Windows commands use the virtual environment Python directly, so PowerShell execution-policy restrictions on `Activate.ps1` do not affect setup.

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe scripts\bootstrap.py
.\.venv\Scripts\python.exe scripts\run_demo.py
```

If you installed Python 3.11, use `py -3.11` in the first command. If the `py` launcher is unavailable, use `python -m venv .venv` after checking `python --version`.

Open **http://localhost:8000** for the custom executive application. API documentation: **http://localhost:8000/docs**. Press **Ctrl+C** in the launcher terminal to stop both services.

### macOS/Linux

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python scripts/bootstrap.py
.venv/bin/python scripts/run_demo.py
```

## 3. Configure VS Code debugging

Press **Ctrl+Shift+P → Python: Select Interpreter → Enter interpreter path** and select `.venv\Scripts\python.exe` on Windows. Open **Run and Debug**, select **Sentinel Executive Dashboard + API**, then press **F5**. Stop the command-line launcher before debugging to avoid occupied ports.

Alternatively, start the application and API with one terminal:

```powershell
.\.venv\Scripts\python.exe -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

The original Streamlit prototype is retained at `frontend/app.py` for development reference. It is not the executive presentation screen and is not launched by `run_demo.py`.

### Presentation view versus working data

The app opens in **Illustrative presentation view**. The layout, chart values, KPI values and wording reproduce the supplied reference image. These values are intentionally a static visual reference, not the current detection database. The concept badge remains visible; data freshness and feed health on this view are illustrative too. Its filters are disabled because the reference image supplies only one cohort.

Click **Switch to working data** at the bottom to display actual synthetic case metrics and enable filters. Navigation, chart drill-down and priority actions open the functioning investigation screens using working synthetic data. These screens explicitly identify the dataset change. Verified outcomes and audit records remain connected to the backend.

For a CIO/CTO demonstration: use a desktop viewport around **1536 × 1024**, browser zoom **100%**, and maximise the window. **Export board report** opens the browser print dialog; select **Save as PDF**, landscape, A3 for the full executive page. Other screens export case CSV. No Node.js or frontend build step is required.

## 4. Walk through the application

1. **Overview:** first switch to working data, then filter date cohort, location and category. Inspect risk, accuracy, SLA, trends, patterns and exposure. Select a chart point, then open Inventory Risk to see the matching cases. Export the executive overview as PDF through the print dialog.
2. **Inventory Risk:** filter severity and search SKU/case/reason. Note a case ID.
3. **Investigations:** choose the **analyst** demo role. Select a New case, enter an owner and save **Assigned**. Save **Investigating**. Inspect the reconciliation evidence and ask the local assistant for guidance. Save notes and reviewed/actionable decisions.
4. Record the verified cause, outcome with evidence references, prevention amount and optional proposed stock correction. Move to **Pending approval**.
5. **Resolutions:** switch to **approver**. Select the pending case, verify evidence and save **Resolved**. Only this role can approve resolution. You can then save **Closed**. Closed cases cannot change.
6. **AI Governance:** inspect data exclusions, ingestion timestamp, rule/prompt versions, assistant usage and audit records.

The included database contains 24 cases exercised through the demo workflow, with 16 resolved; synthetic evidence is labelled in the audit trail. Some old cases are deliberately overdue. Resolution durations reflect actual case dates and demo resolution time; metrics are not forced to match illustrative screenshot values. Approving a correction records approval inside this demo database; it does not update an ERP.

## 5. Project layout

```text
inventory_sentinel/
  backend/core.py          SQLite, ingestion, reconciliation, rules, cases, KPIs
  backend/main.py          FastAPI routes and demo role checks
  backend/assistant.py     Local playbook search + optional Chroma/LLM
  frontend/web/            Custom HTML/CSS/JS executive UI, all five screens
  frontend/app.py          Original Streamlit development prototype
  scripts/bootstrap.py    Deterministic generation + detection + demo outcomes
  scripts/ingest.py        Re-ingest current source CSV; preserve case progress
  scripts/run_demo.py      Launch API and dashboard together
  data/                   Synthetic CSVs and SQLite database
  playbooks/              Editable investigation guidance
  tests/                  Detection, workflow and API tests
  docs/                   Data dictionary, architecture and development roadmap
  .vscode/                Debugger and extension configuration
```

## 6. Data and detections

The generator creates **3,360 daily SKU/location observations**, **26,880 event rows**, 12 SKUs, 5 locations and 56 days. It injects count variance, receipt mismatch, repeated adjustments, negative stock, scan exceptions, unusual variance and incomplete feeds. Ground-truth labels are supplied for evaluation and are **not read by detection**.

Rule signals are grouped into one case per source observation. Exposure takes the **largest** signal estimate within a case as a conservative demo method, rather than adding overlapping estimates. Different days remain distinct cases; cross-day incident deduplication is a production enhancement.

Stock reconciliation:

`expected = opening + received + inbound + returns - sales - outbound + adjustment`

`variance = counted - expected`

Detection thresholds live in `backend/core.py`. Historical detection uses only prior complete records for the same SKU/location; it requires 14 prior observations and a trailing window of up to 28. Incomplete feeds are retained as observations but excluded from alerts and accuracy. Dates/timestamps are UTC; currencies are INR and quantities use EA.

After editing `data/inventory_daily.csv`, run:

```powershell
.\.venv\Scripts\python.exe scripts\ingest.py
```

Refresh the UI. Ingestion preserves existing case status and original detection evidence. Source changes to an existing observation do not revise an existing case's risk; production corrections require explicit case supersession/versioning. To create a clean demo, stop services, rename `data\sentinel.db` to retain your work, and rerun bootstrap. Bootstrap regenerates CSV dates relative to the run date; re-running on another date can add a new cohort, so use ingest for ordinary refreshes.

## 7. Optional direct ChromaDB / LLM

The default assistant uses lexical playbook search and deterministic evidence summaries. It is not an LLM and cannot answer arbitrary questions. To enable optional integrations:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-ai.txt
$env:USE_CHROMA = "1"
# Optional: actual external LLM calls; these send case evidence and playbook text to the provider.
$env:OPENAI_API_KEY = "your-key"
$env:OPENAI_MODEL = "gpt-4.1-mini"
.\.venv\Scripts\python.exe scripts\run_demo.py
```

Set a model available to your account. `.env.example` is documentation; `.env` is not automatically loaded. Chroma is called directly, using local hashed lexical embeddings to avoid a model download. For production semantic retrieval, replace these with an approved embedding model and evaluate retrieval quality. Disable integrations by removing the environment variables and restarting. Optional integration failures return a clear unavailable message; the UI does not disguise failures as successful LLM calls.

Never commit API keys. LLM token counts are recorded when returned by the provider. Local summaries incur no LLM tokens. Cost tracking is intentionally not inferred from assumed prices.

## 8. Validation

Run from the project root:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Tests cover feed exclusions, repeat ingestion, overlapping exposure, historical baselines, role restrictions, state transitions, financial bounds, approval, immutable closed cases, filter consistency, API validation and local assistant retrieval.

## 9. Troubleshooting

- **Scripts disabled:** use the direct `.venv\Scripts\python.exe` commands above; activation is unnecessary.
- **Backend unavailable:** start port 8000 first; API and dashboard are separate processes.
- **Port occupied:** stop an earlier launcher/debug session. If changing the API port, set `$env:SENTINEL_API_URL = "http://127.0.0.1:8001"` before launching Streamlit and start uvicorn on 8001.
- **No cases:** run bootstrap from the root, choose Last 60 days and All locations/categories.
- **Permission denied during resolution:** choose the approver demo role and ensure the case is Pending approval.
- **Import error:** install requirements into the same interpreter used for launch/debugging.

## 10. Production boundary

This is a local runnable MVP, not a production deployment. Demo roles are client-selectable headers, not secure authentication. Bind services to loopback as shown. Production work includes verified SSO/JWT authorisation, real source adapters, cross-day incident grouping, reliable scheduled jobs, complete transactional ingestion validation, database migrations/PostgreSQL, monitoring/backups, concurrency/load tests and independent evidence approval. The custom UI matches the reference layout, aqua-blue palette, spacing and typography treatment; the exact proprietary brand font is not bundled. The wordmark is text-rendered, so it is not a pixel-identical official logo asset. See `docs/DEVELOPMENT_PLAN.md`.


## Persona-based access and guardrailed chatbot update
- Demo personas are mapped through the role selector: Store Manager / Viewer (read-only), Warehouse or Loss Prevention / Analyst, Administrator / Approver.
- Backend case updates enforce analyst/approver permissions; resolution requires the approver role and required evidence.
- Added `POST /chat` and a ChatBot assistance workspace. It answers using local case aggregates and approved playbooks, records query metadata in audit/usage tables, and explicitly states that no action was executed.
- Guardrails reject known prompt-injection/secrets requests, requests to accuse people of theft, and requests to approve/execute inventory adjustments. The assistant cannot prove theft and always calls for human verification.
- This is a local demo identity system using headers, not production authentication. Use Entra ID/OIDC/JWT and server-side policy enforcement before deployment.
- **Detection accuracy note:** the supplied VS Code project implements reconciliation rules and a trailing statistical baseline; it does not currently fit an Isolation Forest model. `GET /model-info` describes the active detector truthfully. Isolation Forest should be integrated and validated separately if required; do not label it as active until then.


## Isolation Forest (added)
- The batch ingestion pipeline now fits `sklearn.ensemble.IsolationForest` on complete inventory observations when at least 30 rows are available.
- Feature vector: reconciled `variance_qty`, `shrinkage_pct`, `transaction_velocity`, `scan_count`, `received_qty`, and `sold_qty` (mapped to the project's `received` and `sales` columns).
- The synthetic data generator now supplies `scan_count`, `transaction_velocity`, and `shrinkage_pct`. For legacy CSVs missing these columns, the pipeline derives documented fallback proxies; replace those proxies with actual scan/transaction data for meaningful production detection.
- Model is fitted per batch using `StandardScaler` and deterministic `random_state=42`; `contamination="auto"` is used. Predictions are combined with existing rule-based and trailing-baseline flags.
- Each observation stores `ml_anomaly` and `ml_anomaly_score`; lower Isolation Forest decision scores indicate more anomalous records. These scores are not calibrated probabilities.
- Check `GET /model-info` after running ingestion to see model status, features, and training row count.
- Retrain by re-running the ingestion pipeline when new batch data is loaded. This is a demo batch fit, not online learning. Validate against reviewed labels before production.


## Persona-based login (local demo)

The web UI now starts with a sign-in screen and uses a signed bearer token with an 8-hour expiry. The backend verifies the token on dashboard, cases, model-info, chatbot and governance API routes; changing a browser role field or sending a forged role header does not grant privileges. Personas:

- **Store Manager / Viewer** (`viewer`): read-only access.
- **Warehouse Supervisor / Loss Prevention Analyst** (`analyst`): investigate cases and add case updates.
- **Administrator / Approver** (`approver`): authorized resolution approval, subject to the existing evidence and workflow rules.

Local demo accounts (change before use): `manager / Manager@123`, `analyst / Analyst@123`, and `admin / Admin@123`. Set `SENTINEL_AUTH_SECRET` and the six `SENTINEL_*_USER/PASSWORD` variables shown in `.env.example` in the process environment before starting the API. These are demonstration accounts, not enterprise identity. For production, replace this demo login with Microsoft Entra ID/OIDC, validate issuer/audience/signature, use managed secrets, enforce MFA and add rate limiting/lockout and session revocation. The Streamlit alternative still uses demo role selection and should not be exposed as an authenticated production app.

## Persona-based navigation and chat-only assistant

The navigation is now filtered by the authenticated persona:

- **Store Manager / Viewer**: Overview, Inventory Risk, ChatBot assistance (read-only workflow).
- **Warehouse Supervisor / Loss Prevention Analyst**: Overview, Inventory Risk, Investigations, ChatBot assistance.
- **Administrator / Approver**: Overview, Inventory Risk, Investigations, ChatBot assistance, Resolutions, AI Governance.

The **ChatBot assistance** page is a dedicated conversational experience. It does not display the inventory cases table, filters, export control, or dashboard data panels. It sends questions to the authenticated `/chat` endpoint and displays the assistant response, with suggested prompts and a responsible-AI note. The Streamlit frontend follows the same navigation rules and has a separate chat-only page.

Navigation visibility is a user-experience control, not a substitute for authorization. Keep server-side role checks enabled for every sensitive API and use Microsoft Entra ID/OIDC and centrally managed policy for production.
